import React from 'react';
import { formatCurrency, getCategoryMeta } from '../../utils/formatters';
import IconRenderer from '../common/IconRenderer';

export const CategoryBreakdownTable = ({
  categoryTotals,
  totalExpenses,
  currency,
  transactions,
}) => {
  const categoriesList = Object.entries(categoryTotals || {})
    .map(([catId, amount]) => {
      const meta = getCategoryMeta(catId);
      const count = transactions.filter(
        (t) => t.category === catId && t.type === 'expense'
      ).length;
      const share = totalExpenses > 0 ? Math.round((amount / totalExpenses) * 100) : 0;
      return {
        id: catId,
        name: meta.name,
        icon: meta.icon,
        bg: meta.bg,
        amount,
        count,
        share,
      };
    })
    .filter((c) => c.amount > 0)
    .sort((a, b) => b.amount - a.amount);

  if (categoriesList.length === 0) {
    return (
      <div className="p-8 text-center text-slate-400 text-sm">
        No expense records found to generate breakdown table.
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            <th className="py-3 px-4">Category</th>
            <th className="py-3 px-4 text-center">Transactions</th>
            <th className="py-3 px-4 text-right">Total Spent</th>
            <th className="py-3 px-4 text-right">Share of Expense</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
          {categoriesList.map((cat) => (
            <tr
              key={cat.id}
              className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition"
            >
              <td className="py-3 px-4">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${cat.bg}`}
                  >
                    <IconRenderer name={cat.icon} className="w-4 h-4" />
                  </div>
                  <span className="font-semibold text-slate-900 dark:text-white">
                    {cat.name}
                  </span>
                </div>
              </td>
              <td className="py-3 px-4 text-center text-slate-600 dark:text-slate-300 text-xs">
                {cat.count} {cat.count === 1 ? 'record' : 'records'}
              </td>
              <td className="py-3 px-4 text-right font-bold text-rose-600 dark:text-rose-400">
                {formatCurrency(cat.amount, currency)}
              </td>
              <td className="py-3 px-4 text-right font-medium text-slate-700 dark:text-slate-300">
                <div className="inline-flex items-center gap-2">
                  <span>{cat.share}%</span>
                  <div className="w-16 bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden hidden sm:block">
                    <div
                      className="bg-indigo-600 h-full rounded-full"
                      style={{ width: `${cat.share}%` }}
                    />
                  </div>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CategoryBreakdownTable;
