import React, { useState } from 'react';
import { AlertTriangle, AlertOctagon, X, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useBudget } from '../../context/BudgetContext';

export const BudgetAlertBanner = () => {
  const { alerts } = useBudget();
  const [dismissed, setDismissed] = useState(false);

  if (!alerts || alerts.length === 0 || dismissed) {
    return null;
  }

  // Pick the most severe alert
  const hasExceeded = alerts.some((a) => a.type === 'exceeded');
  const alertItem = alerts.find((a) => a.type === 'exceeded') || alerts[0];

  return (
    <div
      className={`rounded-2xl p-4 mb-6 border transition-all ${
        hasExceeded
          ? 'bg-rose-50/90 border-rose-200 text-rose-900 dark:bg-rose-950/40 dark:border-rose-900/60 dark:text-rose-200'
          : 'bg-amber-50/90 border-amber-200 text-amber-900 dark:bg-amber-950/40 dark:border-amber-900/60 dark:text-amber-200'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5 ${
              hasExceeded
                ? 'bg-rose-100 text-rose-600 dark:bg-rose-900 dark:text-rose-300'
                : 'bg-amber-100 text-amber-600 dark:bg-amber-900 dark:text-amber-300'
            }`}
          >
            {hasExceeded ? (
              <AlertOctagon className="w-5 h-5" />
            ) : (
              <AlertTriangle className="w-5 h-5" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-bold">{alertItem.title}</h4>
              {alerts.length > 1 && (
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/60 dark:bg-black/40">
                  +{alerts.length - 1} more alert{alerts.length > 2 ? 's' : ''}
                </span>
              )}
            </div>
            <p className="text-xs mt-0.5 opacity-90">{alertItem.message}</p>
            <div className="mt-2 flex items-center gap-3">
              <Link
                to="/budget"
                className="text-xs font-bold underline flex items-center gap-1 hover:opacity-80"
              >
                <span>View Budget Management</span>
                <ChevronRight className="w-3 h-3" />
              </Link>
            </div>
          </div>
        </div>

        <button
          onClick={() => setDismissed(true)}
          className="p-1 rounded-lg opacity-70 hover:opacity-100 transition"
          aria-label="Dismiss alert"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default BudgetAlertBanner;
