import React from 'react';
import {
  Utensils,
  Home,
  Zap,
  Car,
  Film,
  ShoppingBag,
  HeartPulse,
  GraduationCap,
  Plane,
  MoreHorizontal,
  Briefcase,
  Laptop,
  TrendingUp,
  Award,
  Gift,
  DollarSign,
  HelpCircle,
} from 'lucide-react';

const ICON_MAP = {
  Utensils,
  Home,
  Zap,
  Car,
  Film,
  ShoppingBag,
  HeartPulse,
  GraduationCap,
  Plane,
  MoreHorizontal,
  Briefcase,
  Laptop,
  TrendingUp,
  Award,
  Gift,
  DollarSign,
};

export const IconRenderer = ({ name, className = 'w-5 h-5', ...props }) => {
  const IconComponent = ICON_MAP[name] || HelpCircle;
  return <IconComponent className={className} {...props} />;
};

export default IconRenderer;
