import React from 'react';
import { ArrowUpRight, ArrowDownRight, AlertTriangle } from 'lucide-react';

export const StatCard = ({
  title,
  amount,
  subtitle,
  icon: Icon,
  variant = 'default', // 'income', 'expense', 'balance', 'budget', 'warning'
  progress,
}) => {
  const variantStyles = {
    income: {
      border: 'border-emerald-200 dark:border-emerald-900/40',
      iconBg: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
      amountColor: 'text-emerald-600 dark:text-emerald-400',
      badge: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300',
    },
    expense: {
      border: 'border-rose-200 dark:border-rose-900/40',
      iconBg: 'bg-rose-500/10 text-rose-600 dark:text-rose-400',
      amountColor: 'text-rose-600 dark:text-rose-400',
      badge: 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300',
    },
    balance: {
      border: 'border-indigo-200 dark:border-indigo-900/40',
      iconBg: 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400',
      amountColor: 'text-slate-900 dark:text-white',
      badge: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300',
    },
    budget: {
      border: 'border-purple-200 dark:border-purple-900/40',
      iconBg: 'bg-purple-500/10 text-purple-600 dark:text-purple-400',
      amountColor: 'text-slate-900 dark:text-white',
      badge: 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300',
    },
    warning: {
      border: 'border-amber-300 dark:border-amber-900/60',
      iconBg: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
      amountColor: 'text-amber-600 dark:text-amber-400',
      badge: 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300',
    },
    default: {
      border: 'border-slate-200/80 dark:border-slate-800',
      iconBg: 'bg-slate-500/10 text-slate-600 dark:text-slate-400',
      amountColor: 'text-slate-900 dark:text-white',
      badge: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
    },
  };

  const style = variantStyles[variant] || variantStyles.default;

  return (
    <div
      className={`bg-white dark:bg-slate-900/90 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all duration-200 border ${style.border} relative overflow-hidden`}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold tracking-wider text-slate-500 dark:text-slate-400 uppercase">
            {title}
          </p>
          <h3 className={`text-2xl sm:text-3xl font-extrabold mt-1 tracking-tight ${style.amountColor}`}>
            {amount}
          </h3>
          {subtitle && (
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 flex items-center gap-1 font-medium">
              {subtitle}
            </p>
          )}
        </div>
        {Icon && (
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${style.iconBg} flex-shrink-0`}>
            <Icon className="w-6 h-6" />
          </div>
        )}
      </div>

      {typeof progress === 'number' && (
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/60">
          <div className="flex justify-between text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
            <span>Budget Utilized</span>
            <span className={progress >= 100 ? 'text-rose-500 font-bold' : progress >= 80 ? 'text-amber-500 font-bold' : 'text-slate-700 dark:text-slate-300'}>
              {progress}%
            </span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                progress >= 100
                  ? 'bg-rose-500'
                  : progress >= 80
                  ? 'bg-amber-500'
                  : 'bg-indigo-600'
              }`}
              style={{ width: `${Math.min(100, progress)}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default StatCard;
