import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from 'recharts';
import { useTransactions } from '../../context/TransactionContext';
import { formatCurrency } from '../../utils/formatters';
import { useTheme } from '../../context/ThemeContext';

export const IncomeExpenseChart = () => {
  const { monthlyTrend, currency } = useTransactions();
  const { isDark } = useTheme();

  if (!monthlyTrend || monthlyTrend.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 flex items-center justify-center min-h-[300px]">
        <p className="text-sm text-slate-400">No monthly data available yet</p>
      </div>
    );
  }

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1.5">
          <p className="font-bold text-slate-800 dark:text-slate-200">{label}</p>
          <p className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center justify-between gap-4">
            <span>Income:</span>
            <span>{formatCurrency(payload[0]?.value || 0, currency)}</span>
          </p>
          <p className="text-rose-600 dark:text-rose-400 font-semibold flex items-center justify-between gap-4">
            <span>Expense:</span>
            <span>{formatCurrency(payload[1]?.value || 0, currency)}</span>
          </p>
          <div className="pt-1 border-t border-slate-100 dark:border-slate-800 flex justify-between font-bold text-slate-700 dark:text-slate-300">
            <span>Net:</span>
            <span>
              {formatCurrency(
                (payload[0]?.value || 0) - (payload[1]?.value || 0),
                currency
              )}
            </span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Income vs. Expenses
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Month-over-month financial flow
          </p>
        </div>
      </div>

      <div className="h-64 sm:h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={monthlyTrend}
            margin={{ top: 10, right: 10, left: -15, bottom: 0 }}
          >
            <CartesianGrid
              strokeDasharray="3 3"
              vertical={false}
              stroke={isDark ? '#334155' : '#f1f5f9'}
            />
            <XAxis
              dataKey="label"
              stroke={isDark ? '#94a3b8' : '#64748b'}
              fontSize={12}
              tickLine={false}
              axisLine={false}
            />
            <YAxis
              stroke={isDark ? '#94a3b8' : '#64748b'}
              fontSize={11}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => `${v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v}`}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend
              verticalAlign="top"
              align="right"
              iconType="circle"
              wrapperStyle={{ paddingBottom: '12px', fontSize: '12px' }}
            />
            <Bar
              dataKey="income"
              name="Income"
              fill="#10b981"
              radius={[6, 6, 0, 0]}
              maxBarSize={32}
            />
            <Bar
              dataKey="expense"
              name="Expense"
              fill="#f43f5e"
              radius={[6, 6, 0, 0]}
              maxBarSize={32}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default IncomeExpenseChart;
