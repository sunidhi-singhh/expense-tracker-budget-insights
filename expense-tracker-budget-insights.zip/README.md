# Expense Tracker with Budget Insights

> **Web Development Internship Project**  
> Developed for **Codec Technologies**  
> **Author:** Sunidhi Singh  
> **Tech Stack:** React 18, Vite, Tailwind CSS, Recharts, Lucide Icons, Firebase Auth & Firestore

---

## 🌟 Project Overview

**Expense Tracker with Budget Insights** is a responsive, modern personal finance web application built to help individuals monitor income, track daily expenditures, establish category-specific monthly budget caps, and visualize spending habits through interactive analytical charts.

The application features a responsive design (desktop sidebar navigation and mobile-friendly drawer navigation), dual-mode data persistence (seamless Firebase Cloud Firestore with a 1-click Local Demo Mode fallback), CSV statement exports, printable financial summaries, and real-time threshold warnings (80% warning and 100% exceeded budget alerts).

---

## 🚀 Key Features

### 1. 📊 Financial Dashboard
- **Real-time Summary Cards:** Live display of Monthly Income, Monthly Expenses, Net Monthly Savings (with savings rate %), and Remaining Budget.
- **Income vs. Expense Analytics:** Interactive month-over-month comparison bar chart with custom hover tooltips.
- **Category Spending Doughnut Chart:** Breakdown of current month spending with percentage distribution and categorized color coding.
- **Recent Transactions:** Quick-access list showing transaction badges, dates, payment methods, and inline Edit/Delete actions.
- **Smart Budget Alert Banner:** Prominent warning banner triggered dynamically when total or category spending hits 80% or exceeds the allocated budget.

### 2. 💳 Transaction Management
- **Add Income & Expense:** Modal accessible from anywhere in the app with field validation (title, positive amount > 0, category, date, payment method, optional notes).
- **Edit & Delete Records:** Instant updates to dashboard totals, charts, and budget progress bars.
- **Confetti Celebration:** Festive animation triggered upon recording income or staying within budget targets.

### 3. 📜 Transaction History & Filtering
- **Multi-Filter Engine:** Filter records by transaction type (Income / Expense), category, or date range presets (*All Time*, *This Month*, *Last Month*, *Last 30 Days*, or *Custom Start/End Dates*).
- **Live Search:** Instant search across transaction titles and notes.
- **Flexible Sorting:** Sort by Date (newest/oldest), Amount (highest/lowest), or Title (A–Z).
- **Responsive Table & Mobile Cards:** Clean table on desktop and compact card layout on mobile screens with pagination controls.

### 4. 🎯 Budget Management & Insights
- **Overall Monthly Budget:** Set and adjust overall monthly expenditure targets.
- **Category-Wise Spending Limits:** Define quotas for Food & Dining, Rent, Utilities, Transport, Entertainment, Shopping, Healthcare, etc.
- **Visual Progress Gauges:** Color-coded progress bars:
  - 🟢 **Normal / Healthy:** Spending < 80% of budget.
  - 🟡 **Warning Threshold:** Spending between 80% and 99% (prompts user to slow down).
  - 🔴 **Exceeded Threshold:** Spending ≥ 100% (urgent alert with overbudget delta).

### 5. 📑 Reports, CSV Export & Printable Statements
- **Financial Trend Area Chart:** Cumulative cash flow and net savings trajectory.
- **Category Breakdown Table:** Detailed spending volume, transaction count, and percentage contribution.
- **CSV Data Export:** One-click download of all or filtered transactions formatted with standard headers.
- **Printable Monthly Summary:** Clean, printer-optimized statement (`window.print()`) featuring internship metadata, user details, key financial metrics, category breakdown, and signature section.

### 6. 🔐 Authentication & Multi-Tenant Security
- **Firebase Authentication:** Secure email/password registration, login, and Google Sign-in.
- **Multi-Tenant User Isolation:** Each user's financial records are stored under `users/{userId}/transactions` and protected by Firestore Security Rules.
- **1-Click Reviewer Demo Mode:** Allows internship evaluators to test all features immediately without entering Firebase credentials or configuring API keys.

### 7. ⚙️ Settings & Customization
- **Currency Selection:** Instant switching between **INR (₹)**, **USD ($)**, **EUR (€)**, **GBP (£)**, **CAD (CA$)**, **AUD (AU$)**, **JPY (¥)**, and **SGD (S$)**.
- **Dark / Light Theme Toggle:** Smooth visual transition with preference persisted in `localStorage`.
- **Display Profile Management:** Update user display name.
- **Demo Data Reset:** Easily restore the default realistic internship dataset or wipe records for clean testing.

---

## 🛠️ Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend Framework** | React.js (v18) with Vite 6 |
| **Styling** | Tailwind CSS v3, PostCSS, Autoprefixer |
| **Routing** | React Router DOM v6 |
| **Icons** | Lucide React |
| **Data Visualization** | Recharts (Responsive Bar, Doughnut, and Area charts) |
| **Backend & Auth** | Google Firebase Authentication & Cloud Firestore |
| **Local Storage** | Fallback service layer with automatic mock data seeding |
| **Animations & FX** | Canvas Confetti, Tailwind Transition Animations |

---

## 📁 Project Architecture

```
expense-tracker-with-budget-insights/
├── public/
├── src/
│   ├── components/
│   │   ├── auth/
│   │   │   └── ProtectedRoute.jsx        # Route authentication guard
│   │   ├── common/
│   │   │   ├── EmptyState.jsx            # Empty state fallback with action button
│   │   │   ├── IconRenderer.jsx          # Dynamic Lucide icon mapper
│   │   │   ├── LoadingSpinner.jsx        # Loading indicator
│   │   │   ├── Modal.jsx                 # Accessible dialog modal
│   │   │   ├── Navbar.jsx                # Responsive header with theme/currency controls
│   │   │   ├── Sidebar.jsx               # Desktop sidebar & mobile navigation drawer
│   │   │   └── StatCard.jsx              # Summary metrics card with progress bar
│   │   ├── dashboard/
│   │   │   ├── CategoryDoughnutChart.jsx # Category breakdown doughnut chart
│   │   │   ├── IncomeExpenseChart.jsx    # Monthly comparison bar chart
│   │   │   ├── OverviewSummary.jsx       # 4 top financial summary metrics
│   │   │   └── RecentTransactionsList.jsx# Recent transactions list with inline actions
│   │   ├── transactions/
│   │   │   ├── DeleteConfirmModal.jsx    # Transaction deletion confirm modal
│   │   │   ├── TransactionFilters.jsx    # Multi-field search, filter, and sort bar
│   │   │   ├── TransactionFormModal.jsx  # Add & Edit transaction form modal
│   │   │   └── TransactionTable.jsx      # Responsive table, mobile cards & pagination
│   │   ├── budget/
│   │   │   ├── BudgetAlertBanner.jsx     # Threshold warning alert banner
│   │   │   ├── CategoryBudgetCard.jsx    # Category budget card with progress bar
│   │   │   └── SetBudgetModal.jsx        # Budget configuration modal
│   │   └── reports/
│   │       ├── CategoryBreakdownTable.jsx# Tabular expense breakdown
│   │       └── PrintableReport.jsx       # Printable monthly statement modal
│   ├── context/
│   │   ├── AuthContext.jsx               # Firebase Auth state & Demo login provider
│   │   ├── BudgetContext.jsx             # Budget calculations, limits, and alerts
│   │   ├── NotificationContext.jsx       # Global toast notification system
│   │   ├── ThemeContext.jsx              # Dark / Light mode provider
│   │   └── TransactionContext.jsx        # Transactions state, metrics & currency
│   ├── services/
│   │   ├── demoData.js                   # Realistic sample dataset for internship demo
│   │   ├── firebase.js                   # Firebase SDK initialization & verification
│   │   └── storageService.js             # Dual Firestore / LocalStorage abstraction
│   ├── utils/
│   │   ├── constants.js                  # Categories, payment methods, currencies
│   │   ├── exportCsv.js                  # CSV file generator & downloader
│   │   └── formatters.js                 # Currency & date format helpers
│   ├── pages/
│   │   ├── BudgetPage.jsx                # Budget management page
│   │   ├── DashboardPage.jsx             # Main dashboard view
│   │   ├── LoginPage.jsx                 # Login & 1-click demo entry
│   │   ├── RegisterPage.jsx              # Registration page
│   │   ├── ReportsPage.jsx               # Reports, analytics & printable summary
│   │   ├── SettingsPage.jsx              # Preferences, theme, currency & data options
│   │   └── TransactionsPage.jsx          # Transaction history with filtering
│   ├── App.jsx                           # Application routing & layout tree
│   ├── index.css                         # Tailwind CSS directives & print styles
│   └── main.jsx                          # React DOM entry point
├── .env.example                          # Environment variable configuration template
├── firestore.rules                       # Firestore multi-tenant security rules
├── index.html                            # HTML5 entry with Inter font
├── package.json                          # Dependencies and npm scripts
├── postcss.config.js                     # PostCSS config
├── tailwind.config.js                    # Tailwind theme customization
└── vite.config.js                        # Vite config with manual chunk splitting
```

---

## 💻 Installation & Local Setup

### Prerequisites
- [Node.js](https://nodejs.org/) (Version 18 or later recommended)
- `npm` or `pnpm` / `yarn`

### Step 1: Clone or Navigate to the Workspace
```bash
cd "c:\Users\Anand\Desktop\project 1"
```

### Step 2: Install Dependencies
```bash
npm install
```

### Step 3: Configure Environment Variables (Optional)
If you wish to connect a live Firebase project:
1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Open `.env` and fill in your Firebase project credentials (see [Firebase Configuration](#-firebase-configuration)).

> **Note:** If `.env` is omitted or contains placeholder values, the application **automatically boots in Local Demo Mode** with realistic internship data. It will **never crash** due to missing credentials!

### Step 4: Run the Development Server
```bash
npm run dev
```
Open your browser and navigate to `http://localhost:3000` (or the port specified in terminal output).

### Step 5: Build for Production
```bash
npm run build
```
To preview the production build locally:
```bash
npm run preview
```

---

## 🔥 Firebase Configuration Guide

Follow these steps to link your live Google Firebase backend:

1. **Create a Firebase Project:**
   - Go to the [Firebase Console](https://console.firebase.google.com/).
   - Click **Add Project**, name it (e.g., `expense-tracker-codec`), and continue.

2. **Enable Firebase Authentication:**
   - In the left sidebar, click **Build > Authentication**.
   - Click **Get Started**.
   - Under the **Sign-in method** tab, enable **Email/Password** and optionally **Google**.

3. **Enable Cloud Firestore Database:**
   - In the left sidebar, click **Build > Firestore Database**.
   - Click **Create Database**.
   - Select your preferred region (e.g., `asia-south1` or `us-central1`).
   - Start in **Production Mode**.

4. **Apply Firestore Security Rules:**
   - Navigate to the **Rules** tab in Firestore Database.
   - Copy the contents of [`firestore.rules`](./firestore.rules) from this project and paste them:
     ```javascript
     rules_version = '2';
     service cloud.firestore {
       match /databases/{database}/documents {
         match /users/{userId} {
           allow read, write: if request.auth != null && request.auth.uid == userId;

           match /transactions/{transactionId} {
             allow read, write: if request.auth != null && request.auth.uid == userId;
           }

           match /meta/{metaDoc} {
             allow read, write: if request.auth != null && request.auth.uid == userId;
           }
         }
         match /{document=**} {
           allow read, write: if false;
         }
       }
     }
     ```
   - Click **Publish**.

5. **Register a Web App & Retrieve API Keys:**
   - Click the gear icon ⚙️ next to **Project Overview** > **Project Settings**.
   - Under **Your apps**, click the **Web (</>)** icon.
   - Register the app name (e.g., `ExpenseTrackerWeb`).
   - Copy the values from `firebaseConfig` into your `.env` file:
     ```env
     VITE_FIREBASE_API_KEY=AIzaSy...
     VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
     VITE_FIREBASE_PROJECT_ID=your-project
     VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
     VITE_FIREBASE_MESSAGING_SENDER_ID=1234567890
     VITE_FIREBASE_APP_ID=1:1234567890:web:...
     ```
   - Restart your Vite development server (`npm run dev`). The status badge in the app will update to **Live Firestore Connected**.

---

## 🚀 Publishing to GitHub & Deploying

### 1. Push to GitHub
```bash
# Initialize git repository (if not already done)
git init
git add .
git commit -m "feat: complete expense tracker with budget insights for Codec internship"

# Link to your GitHub repository
git branch -M main
git remote add origin https://github.com/<your-username>/expense-tracker-budget-insights.git
git push -u origin main
```

### 2. Deploy to Vercel (Recommended)
1. Sign in to [Vercel](https://vercel.com/) with GitHub.
2. Click **Add New > Project** and import `expense-tracker-budget-insights`.
3. In **Environment Variables**, add the `VITE_FIREBASE_*` variables from your `.env` (if using live Firebase).
4. Click **Deploy**. Vercel will build and assign a free HTTPS URL.

### 3. Deploy to Firebase Hosting
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
# Select: "Use an existing project"
# What do you want to use as your public directory? -> dist
# Configure as a single-page app (rewrite all urls to /index.html)? -> Yes
# Set up automatic builds and deploys with GitHub? -> Optional (No/Yes)
npm run build
firebase deploy --only hosting
```

---

## ✅ Implemented Requirements & Verification

| Requirement | Implementation Detail | Status |
|---|---|---|
| **Responsive Finance Dashboard** | Desktop sidebar + mobile header/drawer navigation with summary cards | ✅ Complete |
| **Income vs Expense Chart** | Recharts Bar Chart with month-over-month trend and custom tooltips | ✅ Complete |
| **Category Spending Chart** | Recharts Doughnut Chart with color swatches and percentage shares | ✅ Complete |
| **Add / Edit / Delete Transactions** | Modal dialog with real-time validation (rejects negative/zero amounts) | ✅ Complete |
| **Transaction History** | Table view on desktop, mobile cards, search by text, category/type/date filters | ✅ Complete |
| **Budget Management** | Overall monthly budget, category limits, visual progress bars | ✅ Complete |
| **Budget Alerting (80% & 100%)** | Amber alert when ≥ 80% spent, Red danger alert when exceeded | ✅ Complete |
| **Reports & Analytics** | Area trend charts, category breakdown tables, savings rate metric | ✅ Complete |
| **Export to CSV** | Instant client-side CSV download with formatted dates, types, notes | ✅ Complete |
| **Printable Summary Report** | Dedicated print-styled modal with `@media print` styling | ✅ Complete |
| **Firebase Auth & Firestore** | Email/Password, Google Auth, user-isolated Firestore subcollections | ✅ Complete |
| **Zero-Crash Demo Mode** | Fallback service layer with realistic internship dataset | ✅ Complete |
| **Settings & Customization** | Display name, 8 currency symbols (INR, USD, EUR, etc.), Light/Dark theme | ✅ Complete |

---

## 💡 Notes & Remaining Limitations

1. **Email Verification:** Standard email/password registration is configured. Live production deployments can optionally turn on Firebase email link verification.
2. **Offline Data Sync:** Local Demo Mode uses browser `localStorage`. Real Firestore sync uses Firebase's built-in offline caching when Firebase is configured.
3. **Receipt Image Attachment:** Transactions currently support rich metadata, notes, and payment methods. File upload to Firebase Cloud Storage can be added as a future enhancement.

---

## 🎓 Internship Project Submission

- **Organization:** Codec Technologies  
- **Project Title:** Expense Tracker with Budget Insights  
- **Developer:** Sunidhi Singh (Web Development Intern)  
- **Submission Date:** October 2026
