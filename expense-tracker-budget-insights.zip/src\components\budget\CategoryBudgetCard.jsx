import React from 'react';
import { AlertTriangle, AlertCircle, CheckCircle2 } from 'lucide-react';
import IconRenderer from '../common/IconRenderer';
import { formatCurrency } from '../../utils/formatters';

export const CategoryBudgetCard = ({
  categoryStatus,
  currency,
  onEdit,
}) => {
  const {
    categoryId,
    name,
    icon,
    spent,
    budget,
    remaining,
    percentage,
    isWarning,
    isExceeded,
    bg,
  } = categoryStatus;

  return (
    <div
      className={`bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border transition-all shadow-sm ${
        isExceeded
          ? 'border-rose-300 dark:border-rose-900/60 bg-rose-50/20 dark:bg-rose-950/20'
          : isWarning
          ? 'border-amber-300 dark:border-amber-900/60 bg-amber-50/20 dark:bg-amber-950/20'
          : 'border-slate-200/80 dark:border-slate-800'
      }`}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-3 min-w-0">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${bg}`}
          >
            <IconRenderer name={icon} className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
              {name}
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Budget: {formatCurrency(budget, currency)}
            </p>
          </div>
        </div>

        {/* Status Badge */}
        {isExceeded ? (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300">
            <AlertCircle className="w-3 h-3" /> Exceeded
          </span>
        ) : isWarning ? (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300">
            <AlertTriangle className="w-3 h-3" /> 80% Reached
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
            <CheckCircle2 className="w-3 h-3" /> On Track
          </span>
        )}
      </div>

      {/* Progress Bar */}
      <div className="space-y-1.5 my-3">
        <div className="flex justify-between text-xs font-semibold">
          <span className="text-slate-600 dark:text-slate-300">
            Spent: {formatCurrency(spent, currency)}
          </span>
          <span
            className={
              isExceeded
                ? 'text-rose-600 font-bold'
                : isWarning
                ? 'text-amber-600 font-bold'
                : 'text-slate-500 dark:text-slate-400'
            }
          >
            {percentage}%
          </span>
        </div>
        <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2.5 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              isExceeded
                ? 'bg-rose-500'
                : isWarning
                ? 'bg-amber-500'
                : 'bg-indigo-600'
            }`}
            style={{ width: `${Math.min(100, percentage)}%` }}
          />
        </div>
      </div>

      {/* Footer Info */}
      <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800/80 text-xs">
        <span className="text-slate-500 dark:text-slate-400">
          Remaining:
        </span>
        <span
          className={`font-bold ${
            remaining < 0
              ? 'text-rose-600'
              : remaining === 0
              ? 'text-amber-600'
              : 'text-slate-900 dark:text-slate-200'
          }`}
        >
          {remaining < 0
            ? `-${formatCurrency(Math.abs(remaining), currency)}`
            : formatCurrency(remaining, currency)}
        </span>
      </div>
    </div>
  );
};

export default CategoryBudgetCard;
