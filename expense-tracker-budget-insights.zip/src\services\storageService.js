import { db, isFirebaseConfigured } from './firebase';
import {
  collection,
  doc,
  getDocs,
  setDoc,
  deleteDoc,
  updateDoc,
  getDoc,
  query,
  orderBy,
} from 'firebase/firestore';
import {
  INITIAL_DEMO_TRANSACTIONS,
  INITIAL_DEMO_BUDGETS,
  INITIAL_DEMO_SETTINGS,
} from './demoData';

const LOCAL_STORAGE_PREFIX = 'expense_tracker_';

export const storageService = {
  // TRANSACTIONS
  async getTransactions(userId = 'demo_user') {
    if (isFirebaseConfigured && userId && userId !== 'demo_user' && db) {
      try {
        const txRef = collection(db, 'users', userId, 'transactions');
        const q = query(txRef, orderBy('date', 'desc'));
        const snapshot = await getDocs(q);
        const list = [];
        snapshot.forEach((d) => {
          list.push({ id: d.id, ...d.data() });
        });
        return list;
      } catch (err) {
        console.error('Error fetching transactions from Firestore:', err);
        // Fallback to local storage if network or permissions fail
        return this.getLocalTransactions(userId);
      }
    } else {
      return this.getLocalTransactions(userId);
    }
  },

  getLocalTransactions(userId) {
    const key = `${LOCAL_STORAGE_PREFIX}transactions_${userId}`;
    const data = localStorage.getItem(key);
    if (!data) {
      // Seed with initial realistic demo data
      localStorage.setItem(key, JSON.stringify(INITIAL_DEMO_TRANSACTIONS));
      return INITIAL_DEMO_TRANSACTIONS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_DEMO_TRANSACTIONS;
    }
  },

  async addTransaction(userId = 'demo_user', transaction) {
    const newTx = {
      ...transaction,
      id: transaction.id || `tx_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    if (isFirebaseConfigured && userId && userId !== 'demo_user' && db) {
      try {
        const docRef = doc(db, 'users', userId, 'transactions', newTx.id);
        await setDoc(docRef, newTx);
        return newTx;
      } catch (err) {
        console.error('Firestore save failed, saving locally:', err);
        return this.addLocalTransaction(userId, newTx);
      }
    } else {
      return this.addLocalTransaction(userId, newTx);
    }
  },

  addLocalTransaction(userId, newTx) {
    const list = this.getLocalTransactions(userId);
    const updated = [newTx, ...list];
    localStorage.setItem(`${LOCAL_STORAGE_PREFIX}transactions_${userId}`, JSON.stringify(updated));
    return newTx;
  },

  async updateTransaction(userId = 'demo_user', id, updatedFields) {
    if (isFirebaseConfigured && userId && userId !== 'demo_user' && db) {
      try {
        const docRef = doc(db, 'users', userId, 'transactions', id);
        const payload = { ...updatedFields, updatedAt: new Date().toISOString() };
        await updateDoc(docRef, payload);
        return { id, ...payload };
      } catch (err) {
        console.error('Firestore update failed, updating locally:', err);
        return this.updateLocalTransaction(userId, id, updatedFields);
      }
    } else {
      return this.updateLocalTransaction(userId, id, updatedFields);
    }
  },

  updateLocalTransaction(userId, id, updatedFields) {
    const list = this.getLocalTransactions(userId);
    const updated = list.map((item) =>
      item.id === id ? { ...item, ...updatedFields, updatedAt: new Date().toISOString() } : item
    );
    localStorage.setItem(`${LOCAL_STORAGE_PREFIX}transactions_${userId}`, JSON.stringify(updated));
    return updated.find((t) => t.id === id);
  },

  async deleteTransaction(userId = 'demo_user', id) {
    if (isFirebaseConfigured && userId && userId !== 'demo_user' && db) {
      try {
        const docRef = doc(db, 'users', userId, 'transactions', id);
        await deleteDoc(docRef);
        return true;
      } catch (err) {
        console.error('Firestore delete failed, deleting locally:', err);
        return this.deleteLocalTransaction(userId, id);
      }
    } else {
      return this.deleteLocalTransaction(userId, id);
    }
  },

  deleteLocalTransaction(userId, id) {
    const list = this.getLocalTransactions(userId);
    const updated = list.filter((item) => item.id !== id);
    localStorage.setItem(`${LOCAL_STORAGE_PREFIX}transactions_${userId}`, JSON.stringify(updated));
    return true;
  },

  // BUDGETS
  async getBudgets(userId = 'demo_user') {
    if (isFirebaseConfigured && userId && userId !== 'demo_user' && db) {
      try {
        const docRef = doc(db, 'users', userId, 'meta', 'budgets');
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          return snap.data();
        }
        return INITIAL_DEMO_BUDGETS;
      } catch {
        return this.getLocalBudgets(userId);
      }
    } else {
      return this.getLocalBudgets(userId);
    }
  },

  getLocalBudgets(userId) {
    const key = `${LOCAL_STORAGE_PREFIX}budgets_${userId}`;
    const data = localStorage.getItem(key);
    if (!data) {
      localStorage.setItem(key, JSON.stringify(INITIAL_DEMO_BUDGETS));
      return INITIAL_DEMO_BUDGETS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_DEMO_BUDGETS;
    }
  },

  async saveBudgets(userId = 'demo_user', budgets) {
    if (isFirebaseConfigured && userId && userId !== 'demo_user' && db) {
      try {
        const docRef = doc(db, 'users', userId, 'meta', 'budgets');
        await setDoc(docRef, budgets, { merge: true });
        return budgets;
      } catch {
        return this.saveLocalBudgets(userId, budgets);
      }
    } else {
      return this.saveLocalBudgets(userId, budgets);
    }
  },

  saveLocalBudgets(userId, budgets) {
    const key = `${LOCAL_STORAGE_PREFIX}budgets_${userId}`;
    localStorage.setItem(key, JSON.stringify(budgets));
    return budgets;
  },

  // SETTINGS
  async getSettings(userId = 'demo_user') {
    if (isFirebaseConfigured && userId && userId !== 'demo_user' && db) {
      try {
        const docRef = doc(db, 'users', userId, 'meta', 'settings');
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          return snap.data();
        }
        return INITIAL_DEMO_SETTINGS;
      } catch {
        return this.getLocalSettings(userId);
      }
    } else {
      return this.getLocalSettings(userId);
    }
  },

  getLocalSettings(userId) {
    const key = `${LOCAL_STORAGE_PREFIX}settings_${userId}`;
    const data = localStorage.getItem(key);
    if (!data) {
      localStorage.setItem(key, JSON.stringify(INITIAL_DEMO_SETTINGS));
      return INITIAL_DEMO_SETTINGS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_DEMO_SETTINGS;
    }
  },

  async saveSettings(userId = 'demo_user', settings) {
    if (isFirebaseConfigured && userId && userId !== 'demo_user' && db) {
      try {
        const docRef = doc(db, 'users', userId, 'meta', 'settings');
        await setDoc(docRef, settings, { merge: true });
        return settings;
      } catch {
        return this.saveLocalSettings(userId, settings);
      }
    } else {
      return this.saveLocalSettings(userId, settings);
    }
  },

  saveLocalSettings(userId, settings) {
    const key = `${LOCAL_STORAGE_PREFIX}settings_${userId}`;
    localStorage.setItem(key, JSON.stringify(settings));
    return settings;
  },

  // RESET TO DEMO DATA
  async resetToDemoData(userId = 'demo_user') {
    localStorage.setItem(`${LOCAL_STORAGE_PREFIX}transactions_${userId}`, JSON.stringify(INITIAL_DEMO_TRANSACTIONS));
    localStorage.setItem(`${LOCAL_STORAGE_PREFIX}budgets_${userId}`, JSON.stringify(INITIAL_DEMO_BUDGETS));
    localStorage.setItem(`${LOCAL_STORAGE_PREFIX}settings_${userId}`, JSON.stringify(INITIAL_DEMO_SETTINGS));
    return true;
  },

  // CLEAR ALL TRANSACTIONS
  async clearAllData(userId = 'demo_user') {
    localStorage.setItem(`${LOCAL_STORAGE_PREFIX}transactions_${userId}`, JSON.stringify([]));
    return true;
  }
};
