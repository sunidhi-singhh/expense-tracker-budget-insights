import { CATEGORIES } from './constants';

export const formatCurrency = (amount, currencyCode = 'INR') => {
  const num = typeof amount === 'number' ? amount : parseFloat(amount) || 0;
  
  const currencySymbols = {
    INR: '₹',
    USD: '$',
    EUR: '€',
    GBP: '£',
    CAD: 'CA$',
    AUD: 'AU$',
    JPY: '¥',
    SGD: 'S$',
  };

  const symbol = currencySymbols[currencyCode] || '₹';
  
  // Format with thousands separator
  const formattedNumber = new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  }).format(num);

  return `${symbol}${formattedNumber}`;
};

export const formatDate = (dateString, options = {}) => {
  if (!dateString) return 'N/A';
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    
    if (options.short) {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
    if (options.monthYear) {
      return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    }
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateString;
  }
};

export const getCategoryMeta = (categoryId) => {
  return CATEGORIES[categoryId] || {
    id: categoryId || 'other_expense',
    name: categoryId || 'Other',
    type: 'expense',
    icon: 'MoreHorizontal',
    color: '#64748b',
    bg: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
  };
};

export const getMonthKey = (dateString) => {
  const d = dateString ? new Date(dateString) : new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
};
