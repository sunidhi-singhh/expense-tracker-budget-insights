import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  PiggyBank,
  AlertCircle,
} from 'lucide-react';
import StatCard from '../common/StatCard';
import { useTransactions } from '../../context/TransactionContext';
import { useBudget } from '../../context/BudgetContext';
import { formatCurrency } from '../../utils/formatters';

export const OverviewSummary = () => {
  const {
    currentMonthIncome,
    currentMonthExpenses,
    currentMonthBalance,
    savingsRate,
    currency,
  } = useTransactions();

  const {
    overallBudget,
    overallRemaining,
    overallPercentage,
    overallStatus,
  } = useBudget();

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
      {/* 1. Total Income */}
      <StatCard
        title="Monthly Income"
        amount={formatCurrency(currentMonthIncome, currency)}
        subtitle="This month's total earned"
        icon={TrendingUp}
        variant="income"
      />

      {/* 2. Total Expenses */}
      <StatCard
        title="Monthly Expenses"
        amount={formatCurrency(currentMonthExpenses, currency)}
        subtitle="This month's expenditures"
        icon={TrendingDown}
        variant="expense"
      />

      {/* 3. Current Balance */}
      <StatCard
        title="Net Monthly Savings"
        amount={formatCurrency(currentMonthBalance, currency)}
        subtitle={`${savingsRate}% savings rate`}
        icon={PiggyBank}
        variant="balance"
      />

      {/* 4. Remaining Budget */}
      <StatCard
        title="Remaining Budget"
        amount={formatCurrency(overallRemaining, currency)}
        subtitle={
          overallStatus === 'exceeded'
            ? 'Budget limit exceeded!'
            : overallStatus === 'warning'
            ? 'Approaching 80% limit'
            : 'Within healthy budget limits'
        }
        icon={overallStatus === 'exceeded' ? AlertCircle : Wallet}
        variant={overallStatus === 'exceeded' ? 'expense' : overallStatus === 'warning' ? 'warning' : 'budget'}
        progress={overallPercentage}
      />
    </div>
  );
};

export default OverviewSummary;
