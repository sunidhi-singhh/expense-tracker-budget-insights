import React, { useState } from 'react';
import {
  User,
  Moon,
  Sun,
  Coins,
  Database,
  RotateCcw,
  Trash2,
  Check,
  ShieldCheck,
  Sparkles,
  Info,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTransactions } from '../context/TransactionContext';
import { useTheme } from '../context/ThemeContext';
import { useNotification } from '../context/NotificationContext';
import { CURRENCIES } from '../utils/constants';

export const SettingsPage = () => {
  const { currentUser, updateUserProfile, isFirebaseConfigured } = useAuth();
  const { currency, setCurrency, resetToDemoData, clearAllData } = useTransactions();
  const { theme, setTheme } = useTheme();
  const { showToast } = useNotification();

  const [displayName, setDisplayName] = useState(currentUser?.displayName || '');
  const [savingProfile, setSavingProfile] = useState(false);

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    if (!displayName.trim()) {
      showToast('Name cannot be empty', 'error');
      return;
    }
    setSavingProfile(true);
    try {
      await updateUserProfile({ displayName: displayName.trim() });
      showToast('Profile name updated successfully', 'success');
    } catch {
      showToast('Failed to update profile name', 'error');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleResetDemo = async () => {
    if (
      window.confirm(
        'Restore the Codec Technologies internship demo dataset? This will replace current records with sample data.'
      )
    ) {
      await resetToDemoData();
    }
  };

  const handleClearAll = async () => {
    if (
      window.confirm(
        'Are you sure you want to delete ALL transactions? This action is permanent!'
      )
    ) {
      await clearAllData();
    }
  };

  return (
    <div className="space-y-6 pb-12 max-w-4xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          Application Settings
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Customize your profile, preferred currency, theme, and data storage.
        </p>
      </div>

      {/* 1. Profile Settings */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
            <User className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              User Profile
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Personalize your display identity
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveProfile} className="space-y-3 pt-2">
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">
              Display Name
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="e.g. Anand Sharma"
              className="w-full sm:w-96 px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">
              Email Address
            </label>
            <input
              type="email"
              disabled
              value={currentUser?.email || 'intern@codectechnologies.com'}
              className="w-full sm:w-96 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-800/40 text-slate-500 text-sm cursor-not-allowed"
            />
          </div>

          <button
            type="submit"
            disabled={savingProfile}
            className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm disabled:opacity-50"
          >
            {savingProfile ? 'Saving...' : 'Save Profile'}
          </button>
        </form>
      </div>

      {/* 2. Preferences (Currency & Theme) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/60 flex items-center justify-center text-purple-600 dark:text-purple-400">
            <Coins className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Preferences & Appearance
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Select your currency symbol and visual theme
            </p>
          </div>
        </div>

        {/* Currency Preference */}
        <div className="space-y-2">
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
            Preferred Currency Symbol
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {CURRENCIES.map((c) => {
              const isSelected = currency === c.code;
              return (
                <button
                  key={c.code}
                  type="button"
                  onClick={() => setCurrency(c.code)}
                  className={`p-3 rounded-xl border text-left transition flex items-center justify-between ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200 ring-2 ring-indigo-500/20'
                      : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div>
                    <span className="text-base font-bold block">{c.symbol}</span>
                    <span className="text-xs font-medium opacity-80">{c.code}</span>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Theme Toggle */}
        <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
            Interface Theme
          </label>
          <div className="grid grid-cols-2 gap-3 max-w-sm">
            <button
              type="button"
              onClick={() => setTheme('light')}
              className={`flex items-center gap-2 p-3 rounded-xl border text-xs font-bold transition ${
                theme === 'light'
                  ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/40 text-indigo-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Sun className="w-4 h-4 text-amber-500" />
              <span>Light Mode</span>
            </button>
            <button
              type="button"
              onClick={() => setTheme('dark')}
              className={`flex items-center gap-2 p-3 rounded-xl border text-xs font-bold transition ${
                theme === 'dark'
                  ? 'border-indigo-600 bg-indigo-950/60 text-indigo-300'
                  : 'border-slate-200 dark:border-slate-700 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <Moon className="w-4 h-4 text-indigo-400" />
              <span>Dark Mode</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. Firebase & Storage Status */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Storage & Database Status
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Firebase Authentication and Firestore sync state
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Active Storage Mode:
            </span>
            {isFirebaseConfigured ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                <ShieldCheck className="w-3.5 h-3.5" /> Live Firebase Firestore Connected
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                <Sparkles className="w-3.5 h-3.5" /> Local Storage Demo Mode (Zero Crash Guarantee)
              </span>
            )}
          </div>

          <div className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed space-y-1">
            <p>
              • <strong>Live Firebase Mode:</strong> When you provide your Firebase project API keys in <code className="text-indigo-600 dark:text-indigo-400">.env</code>, data is synchronized with your cloud Firestore database with multi-tenant user isolation.
            </p>
            <p>
              • <strong>Local Storage Demo Mode:</strong> When credentials are omitted, the application runs persistently in your browser with realistic internship mock data so reviewers can test all features immediately without any setup hurdles.
            </p>
          </div>
        </div>
      </div>

      {/* 4. Data Management */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-white">
          Data Management
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Reset to default internship demo dataset or clear data
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleResetDemo}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition"
          >
            <RotateCcw className="w-4 h-4 text-indigo-600" />
            <span>Reset Demo Dataset</span>
          </button>

          <button
            onClick={handleClearAll}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/40 border border-rose-200 dark:border-rose-900/60 rounded-xl transition"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear All Transactions</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
