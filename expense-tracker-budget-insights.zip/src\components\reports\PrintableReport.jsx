import React from 'react';
import { Printer, Download, X } from 'lucide-react';
import Modal from '../common/Modal';
import { formatCurrency, formatDate, getCategoryMeta } from '../../utils/formatters';

export const PrintableReport = ({
  isOpen,
  onClose,
  currentUser,
  currentMonthIncome,
  currentMonthExpenses,
  currentMonthBalance,
  savingsRate,
  overallBudget,
  overallPercentage,
  categoryTotals,
  currency,
  transactions,
}) => {
  const handlePrint = () => {
    window.print();
  };

  const currentMonthName = new Date().toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  });

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Monthly Financial Report Summary"
      subtitle={`Preview report for ${currentMonthName}`}
      maxWidth="max-w-3xl"
    >
      <div className="space-y-6">
        {/* Printable Paper Canvas */}
        <div
          id="printable-report-content"
          className="bg-white text-slate-900 p-6 sm:p-8 rounded-xl border border-slate-200 shadow-sm space-y-6 print:border-none print:shadow-none print:p-0"
        >
          {/* Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-6 border-b-2 border-slate-900 gap-4">
            <div>
              <span className="text-xs uppercase font-extrabold tracking-widest text-indigo-600">
                Codec Technologies Internship Project
              </span>
              <h1 className="text-2xl font-black text-slate-900 mt-1">
                Monthly Financial Statement
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Statement Period: {currentMonthName}
              </p>
            </div>
            <div className="text-left sm:text-right text-xs text-slate-600">
              <p className="font-bold text-slate-900">{currentUser?.displayName || 'Intern User'}</p>
              <p>{currentUser?.email || 'intern@codectechnologies.com'}</p>
              <p className="text-slate-400 mt-1">
                Generated: {new Date().toLocaleDateString()}
              </p>
            </div>
          </div>

          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200 text-center">
            <div>
              <p className="text-[11px] font-bold text-slate-500 uppercase">Total Income</p>
              <p className="text-lg font-black text-emerald-600 mt-1">
                +{formatCurrency(currentMonthIncome, currency)}
              </p>
            </div>
            <div>
              <p className="text-[11px] font-bold text-slate-500 uppercase">Total Expense</p>
              <p className="text-lg font-black text-rose-600 mt-1">
                -{formatCurrency(currentMonthExpenses, currency)}
              </p>
            </div>
            <div>
              <p className="text-[11px] font-bold text-slate-500 uppercase">Net Savings</p>
              <p className="text-lg font-black text-indigo-600 mt-1">
                {formatCurrency(currentMonthBalance, currency)}
              </p>
            </div>
            <div>
              <p className="text-[11px] font-bold text-slate-500 uppercase">Savings Rate</p>
              <p className="text-lg font-black text-slate-800 mt-1">{savingsRate}%</p>
            </div>
          </div>

          {/* Budget Health Check */}
          <div className="p-4 bg-indigo-50/50 rounded-xl border border-indigo-100 flex flex-col sm:flex-row items-center justify-between text-xs gap-3">
            <div>
              <p className="font-bold text-slate-800">Monthly Budget Target:</p>
              <p className="text-slate-600 mt-0.5">
                Allocated budget of {formatCurrency(overallBudget, currency)}, with{' '}
                {overallPercentage}% utilized this month.
              </p>
            </div>
            <span
              className={`px-3 py-1 rounded-full font-bold text-xs ${
                overallPercentage >= 100
                  ? 'bg-rose-100 text-rose-800'
                  : overallPercentage >= 80
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {overallPercentage >= 100
                ? 'Budget Exceeded'
                : overallPercentage >= 80
                ? '80% Warning Limit'
                : 'Within Healthy Budget'}
            </span>
          </div>

          {/* Expense Category Breakdown */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              Expense Distribution By Category
            </h3>
            <table className="w-full text-xs text-left border border-slate-200">
              <thead className="bg-slate-100 font-bold text-slate-700">
                <tr>
                  <th className="p-2 border-b">Category</th>
                  <th className="p-2 border-b text-right">Amount</th>
                  <th className="p-2 border-b text-right">Share</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {Object.entries(categoryTotals || {}).map(([catId, amount]) => {
                  const meta = getCategoryMeta(catId);
                  const share =
                    currentMonthExpenses > 0
                      ? Math.round((amount / currentMonthExpenses) * 100)
                      : 0;
                  return (
                    <tr key={catId}>
                      <td className="p-2 font-medium">{meta.name}</td>
                      <td className="p-2 text-right font-bold text-rose-600">
                        {formatCurrency(amount, currency)}
                      </td>
                      <td className="p-2 text-right">{share}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Footer note */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400 gap-2">
            <span>Codec Technologies • Web Development Internship Final Project</span>
            <span>Generated securely from Expense Tracker with Budget Insights</span>
          </div>
        </div>

        {/* Modal Controls */}
        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 print:hidden">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
          >
            Close
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-sm transition"
          >
            <Printer className="w-4 h-4" />
            <span>Print / Save as PDF</span>
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default PrintableReport;
