import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { storageService } from '../services/storageService';
import { useAuth } from './AuthContext';
import { useNotification } from './NotificationContext';
import { useTransactions } from './TransactionContext';
import { getCategoryMeta } from '../utils/formatters';
import { BUDGET_THRESHOLDS } from '../utils/constants';

const BudgetContext = createContext();

export const BudgetProvider = ({ children }) => {
  const { currentUser } = useAuth();
  const { showToast } = useNotification();
  const { currentMonthExpenses, categoryTotals } = useTransactions();

  const [budgets, setBudgets] = useState({
    overall: 45000,
    categories: {},
  });
  const [loading, setLoading] = useState(true);

  const userId = currentUser?.uid || 'demo_user';

  const loadBudgets = useCallback(async () => {
    setLoading(true);
    try {
      const data = await storageService.getBudgets(userId);
      setBudgets(data || { overall: 45000, categories: {} });
    } catch (err) {
      console.error('Failed to load budgets:', err);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    loadBudgets();
  }, [loadBudgets]);

  const updateOverallBudget = async (newAmount) => {
    const updated = { ...budgets, overall: Math.max(0, Number(newAmount) || 0) };
    setBudgets(updated);
    await storageService.saveBudgets(userId, updated);
    showToast('Overall monthly budget updated', 'success');
  };

  const updateCategoryBudget = async (categoryId, newAmount) => {
    const updatedCategories = {
      ...(budgets.categories || {}),
      [categoryId]: Math.max(0, Number(newAmount) || 0),
    };
    const updated = { ...budgets, categories: updatedCategories };
    setBudgets(updated);
    await storageService.saveBudgets(userId, updated);
    showToast(`Budget for ${getCategoryMeta(categoryId).name} updated`, 'success');
  };

  const updateAllBudgets = async (newBudgets) => {
    setBudgets(newBudgets);
    await storageService.saveBudgets(userId, newBudgets);
    showToast('Budgets saved successfully', 'success');
  };

  // COMPUTED BUDGET ANALYTICS
  const budgetAnalytics = useMemo(() => {
    const overallBudget = Number(budgets.overall) || 0;
    const overallSpent = Number(currentMonthExpenses) || 0;
    const overallRemaining = overallBudget - overallSpent;
    const overallPercentage = overallBudget > 0 ? Math.round((overallSpent / overallBudget) * 100) : 0;

    let overallStatus = 'normal';
    if (overallPercentage >= BUDGET_THRESHOLDS.EXCEEDED) {
      overallStatus = 'exceeded';
    } else if (overallPercentage >= BUDGET_THRESHOLDS.WARNING) {
      overallStatus = 'warning';
    }

    const alerts = [];
    if (overallStatus === 'exceeded') {
      alerts.push({
        type: 'exceeded',
        title: 'Monthly Budget Exceeded!',
        message: `You have spent ${overallPercentage}% of your total monthly budget (${overallRemaining < 0 ? 'Exceeded by ₹' + Math.abs(overallRemaining) : ''}).`,
        category: 'Overall Budget',
      });
    } else if (overallStatus === 'warning') {
      alerts.push({
        type: 'warning',
        title: 'Budget Alert (80% Reached)',
        message: `You have utilized ${overallPercentage}% of your total monthly budget. Slow down spending!`,
        category: 'Overall Budget',
      });
    }

    // Category Wise Status
    const categoryStatusList = Object.entries(budgets.categories || {}).map(([catId, budgetLimit]) => {
      const meta = getCategoryMeta(catId);
      const spent = Number(categoryTotals[catId]) || 0;
      const limit = Number(budgetLimit) || 0;
      const remaining = limit - spent;
      const percentage = limit > 0 ? Math.round((spent / limit) * 100) : 0;
      const isWarning = percentage >= BUDGET_THRESHOLDS.WARNING && percentage < BUDGET_THRESHOLDS.EXCEEDED;
      const isExceeded = percentage >= BUDGET_THRESHOLDS.EXCEEDED;

      if (isExceeded) {
        alerts.push({
          type: 'exceeded',
          title: `${meta.name} Budget Exceeded!`,
          message: `Spent ${spent} of ${limit} limit (${percentage}%).`,
          category: meta.name,
        });
      } else if (isWarning) {
        alerts.push({
          type: 'warning',
          title: `${meta.name} Nearing Limit`,
          message: `Spent ${percentage}% of allocated budget.`,
          category: meta.name,
        });
      }

      return {
        categoryId: catId,
        name: meta.name,
        icon: meta.icon,
        color: meta.color,
        bg: meta.bg,
        budget: limit,
        spent,
        remaining,
        percentage,
        isWarning,
        isExceeded,
      };
    });

    return {
      overallBudget,
      overallSpent,
      overallRemaining,
      overallPercentage,
      overallStatus,
      categoryStatusList,
      alerts,
    };
  }, [budgets, currentMonthExpenses, categoryTotals]);

  return (
    <BudgetContext.Provider
      value={{
        budgets,
        loading,
        updateOverallBudget,
        updateCategoryBudget,
        updateAllBudgets,
        refreshBudgets: loadBudgets,
        ...budgetAnalytics,
      }}
    >
      {children}
    </BudgetContext.Provider>
  );
};

export const useBudget = () => {
  const context = useContext(BudgetContext);
  if (!context) throw new Error('useBudget must be used within BudgetProvider');
  return context;
};
