import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight, ArrowDownRight, Edit2, Trash2, ArrowRight } from 'lucide-react';
import { useTransactions } from '../../context/TransactionContext';
import { formatCurrency, formatDate, getCategoryMeta } from '../../utils/formatters';
import IconRenderer from '../common/IconRenderer';
import TransactionFormModal from '../transactions/TransactionFormModal';
import DeleteConfirmModal from '../transactions/DeleteConfirmModal';

export const RecentTransactionsList = () => {
  const { transactions, currency } = useTransactions();
  const [editingTx, setEditingTx] = useState(null);
  const [deletingTx, setDeletingTx] = useState(null);

  const recentList = transactions.slice(0, 6);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Recent Transactions
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Your latest income and expense entries
          </p>
        </div>
        <Link
          to="/transactions"
          className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 flex items-center gap-1 group"
        >
          <span>View All</span>
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
        </Link>
      </div>

      {recentList.length === 0 ? (
        <div className="py-8 text-center text-slate-400 text-sm">
          No transactions recorded yet.
        </div>
      ) : (
        <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
          {recentList.map((tx) => {
            const meta = getCategoryMeta(tx.category);
            const isIncome = tx.type === 'income';

            return (
              <div
                key={tx.id}
                className="py-3.5 flex items-center justify-between gap-3 group hover:bg-slate-50/60 dark:hover:bg-slate-800/30 px-2 rounded-xl transition"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${meta.bg}`}
                  >
                    <IconRenderer name={meta.icon} className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-200 truncate">
                      {tx.title}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      <span>{formatDate(tx.date, { short: true })}</span>
                      <span>•</span>
                      <span className="truncate">{meta.name}</span>
                      {tx.paymentMethod && (
                        <>
                          <span>•</span>
                          <span className="text-[11px] bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded text-slate-600 dark:text-slate-300">
                            {tx.paymentMethod}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 flex-shrink-0">
                  <div className="text-right">
                    <p
                      className={`text-sm font-bold ${
                        isIncome
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {isIncome ? '+' : '-'} {formatCurrency(tx.amount, currency)}
                    </p>
                    <span className="text-[10px] uppercase font-semibold text-slate-400">
                      {tx.type}
                    </span>
                  </div>

                  {/* Actions (visible on hover / focus) */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                    <button
                      onClick={() => setEditingTx(tx)}
                      className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 rounded-lg transition"
                      title="Edit transaction"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeletingTx(tx)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-lg transition"
                      title="Delete transaction"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Edit Modal */}
      {editingTx && (
        <TransactionFormModal
          isOpen={Boolean(editingTx)}
          onClose={() => setEditingTx(null)}
          initialData={editingTx}
        />
      )}

      {/* Delete Confirmation Modal */}
      {deletingTx && (
        <DeleteConfirmModal
          isOpen={Boolean(deletingTx)}
          onClose={() => setDeletingTx(null)}
          transaction={deletingTx}
        />
      )}
    </div>
  );
};

export default RecentTransactionsList;
