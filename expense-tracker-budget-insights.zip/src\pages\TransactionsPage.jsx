import React, { useState, useMemo } from 'react';
import { Plus, Download, Filter } from 'lucide-react';
import TransactionFilters from '../components/transactions/TransactionFilters';
import TransactionTable from '../components/transactions/TransactionTable';
import TransactionFormModal from '../components/transactions/TransactionFormModal';
import { useTransactions } from '../context/TransactionContext';
import { exportTransactionsToCsv } from '../utils/exportCsv';
import { getMonthKey } from '../utils/formatters';

export const TransactionsPage = () => {
  const { transactions, currency } = useTransactions();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [sortBy, setSortBy] = useState('date-desc');
  const [dateRangePreset, setDateRangePreset] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Filtered & Sorted Transactions
  const filteredTransactions = useMemo(() => {
    const today = new Date();
    const currentMonth = getMonthKey(today);
    
    // Calculate last month key
    const prevMonthDate = new Date();
    prevMonthDate.setMonth(prevMonthDate.getMonth() - 1);
    const lastMonth = getMonthKey(prevMonthDate);

    // Calculate 30 days ago
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    return transactions
      .filter((t) => {
        // Search filter
        if (searchTerm) {
          const term = searchTerm.toLowerCase();
          const matchTitle = (t.title || '').toLowerCase().includes(term);
          const matchNotes = (t.notes || '').toLowerCase().includes(term);
          if (!matchTitle && !matchNotes) return false;
        }

        // Category filter
        if (selectedCategory !== 'all' && t.category !== selectedCategory) {
          return false;
        }

        // Type filter
        if (selectedType !== 'all' && t.type !== selectedType) {
          return false;
        }

        // Date Range preset
        if (dateRangePreset === 'this-month') {
          if (getMonthKey(t.date) !== currentMonth) return false;
        } else if (dateRangePreset === 'last-month') {
          if (getMonthKey(t.date) !== lastMonth) return false;
        } else if (dateRangePreset === 'last-30') {
          const txDate = new Date(t.date);
          if (txDate < thirtyDaysAgo) return false;
        } else if (dateRangePreset === 'custom') {
          if (startDate && t.date < startDate) return false;
          if (endDate && t.date > endDate) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'date-desc') {
          return new Date(b.date) - new Date(a.date);
        }
        if (sortBy === 'date-asc') {
          return new Date(a.date) - new Date(b.date);
        }
        if (sortBy === 'amount-desc') {
          return (Number(b.amount) || 0) - (Number(a.amount) || 0);
        }
        if (sortBy === 'amount-asc') {
          return (Number(a.amount) || 0) - (Number(b.amount) || 0);
        }
        if (sortBy === 'title-asc') {
          return (a.title || '').localeCompare(b.title || '');
        }
        return 0;
      });
  }, [
    transactions,
    searchTerm,
    selectedCategory,
    selectedType,
    sortBy,
    dateRangePreset,
    startDate,
    endDate,
  ]);

  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedCategory('all');
    setSelectedType('all');
    setSortBy('date-desc');
    setDateRangePreset('all');
    setStartDate('');
    setEndDate('');
  };

  const handleExportCsv = () => {
    exportTransactionsToCsv(
      filteredTransactions,
      `transactions_${new Date().toISOString().split('T')[0]}.csv`
    );
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Transaction History
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Search, filter, categorize, and export your personal transactions.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60 rounded-xl transition shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-md shadow-indigo-600/20 active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Add Transaction</span>
          </button>
        </div>
      </div>

      {/* Filter Component */}
      <TransactionFilters
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        selectedType={selectedType}
        setSelectedType={setSelectedType}
        sortBy={sortBy}
        setSortBy={setSortBy}
        dateRangePreset={dateRangePreset}
        setDateRangePreset={setDateRangePreset}
        startDate={startDate}
        setStartDate={setStartDate}
        endDate={endDate}
        setEndDate={setEndDate}
        onReset={handleResetFilters}
      />

      {/* Transaction Table */}
      <TransactionTable
        transactions={filteredTransactions}
        currency={currency}
        onOpenAdd={() => setIsAddModalOpen(true)}
      />

      {/* Add Modal */}
      <TransactionFormModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />
    </div>
  );
};

export default TransactionsPage;
