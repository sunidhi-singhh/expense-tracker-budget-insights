import React, { useState } from 'react';
import { Edit2, Trash2, ChevronLeft, ChevronRight, FileText } from 'lucide-react';
import { formatCurrency, formatDate, getCategoryMeta } from '../../utils/formatters';
import IconRenderer from '../common/IconRenderer';
import TransactionFormModal from './TransactionFormModal';
import DeleteConfirmModal from './DeleteConfirmModal';
import EmptyState from '../common/EmptyState';

export const TransactionTable = ({
  transactions,
  currency,
  onOpenAdd,
}) => {
  const [editingTx, setEditingTx] = useState(null);
  const [deletingTx, setDeletingTx] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  if (transactions.length === 0) {
    return (
      <EmptyState
        title="No matching transactions"
        description="Try adjusting your filters, searching for a different term, or record a new transaction."
        actionLabel="Add Transaction"
        onAction={onOpenAdd}
      />
    );
  }

  // Pagination calculation
  const totalPages = Math.ceil(transactions.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedTransactions = transactions.slice(startIndex, startIndex + itemsPerPage);

  const totalFilteredIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);

  const totalFilteredExpense = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col justify-between">
      {/* Desktop Table View */}
      <div className="overflow-x-auto hidden sm:block">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              <th className="py-3 px-4">Transaction / Category</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4">Date</th>
              <th className="py-3 px-4">Payment Method</th>
              <th className="py-3 px-4 text-right">Amount</th>
              <th className="py-3 px-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
            {paginatedTransactions.map((tx) => {
              const meta = getCategoryMeta(tx.category);
              const isIncome = tx.type === 'income';

              return (
                <tr
                  key={tx.id}
                  className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition group"
                >
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${meta.bg}`}
                      >
                        <IconRenderer name={meta.icon} className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-semibold text-slate-900 dark:text-white truncate">
                          {tx.title}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {meta.name}
                          {tx.notes ? ` • ${tx.notes}` : ''}
                        </p>
                      </div>
                    </div>
                  </td>

                  <td className="py-3 px-4">
                    <span
                      className={`inline-block px-2 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider ${
                        isIncome
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                      }`}
                    >
                      {tx.type}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-slate-600 dark:text-slate-300 text-xs whitespace-nowrap">
                    {formatDate(tx.date)}
                  </td>

                  <td className="py-3 px-4 text-slate-600 dark:text-slate-300 text-xs whitespace-nowrap">
                    <span className="bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded text-slate-700 dark:text-slate-300">
                      {tx.paymentMethod || 'Other'}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <span
                      className={`font-bold ${
                        isIncome
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {isIncome ? '+' : '-'} {formatCurrency(tx.amount, currency)}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => setEditingTx(tx)}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 rounded-lg transition"
                        title="Edit"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeletingTx(tx)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-lg transition"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Mobile Card View */}
      <div className="block sm:hidden divide-y divide-slate-100 dark:divide-slate-800 p-3 space-y-2">
        {paginatedTransactions.map((tx) => {
          const meta = getCategoryMeta(tx.category);
          const isIncome = tx.type === 'income';

          return (
            <div key={tx.id} className="pt-2 pb-3 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${meta.bg}`}
                  >
                    <IconRenderer name={meta.icon} className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                      {tx.title}
                    </h4>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      {formatDate(tx.date, { short: true })} • {meta.name}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <p
                    className={`text-sm font-bold ${
                      isIncome
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {isIncome ? '+' : '-'} {formatCurrency(tx.amount, currency)}
                  </p>
                </div>
              </div>

              {tx.notes && (
                <p className="text-xs text-slate-500 italic bg-slate-50 dark:bg-slate-800/40 p-1.5 rounded-lg">
                  "{tx.notes}"
                </p>
              )}

              <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                  {tx.paymentMethod || 'Online'}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setEditingTx(tx)}
                    className="text-indigo-600 dark:text-indigo-400 font-semibold px-2 py-1"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => setDeletingTx(tx)}
                    className="text-rose-600 dark:text-rose-400 font-semibold px-2 py-1"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Filter Summary Footer & Pagination */}
      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-4 text-slate-600 dark:text-slate-400 font-medium">
          <span>
            Showing <strong className="text-slate-900 dark:text-white">{transactions.length}</strong> transactions
          </span>
          {totalFilteredIncome > 0 && (
            <span className="text-emerald-600 dark:text-emerald-400">
              Income: <strong>+{formatCurrency(totalFilteredIncome, currency)}</strong>
            </span>
          )}
          {totalFilteredExpense > 0 && (
            <span className="text-rose-600 dark:text-rose-400">
              Expenses: <strong>-{formatCurrency(totalFilteredExpense, currency)}</strong>
            </span>
          )}
        </div>

        {/* Pagination Controls */}
        {totalPages > 1 && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-700 transition"
              aria-label="Previous Page"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-slate-600 dark:text-slate-300 font-semibold">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-700 transition"
              aria-label="Next Page"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Edit Modal */}
      {editingTx && (
        <TransactionFormModal
          isOpen={Boolean(editingTx)}
          onClose={() => setEditingTx(null)}
          initialData={editingTx}
        />
      )}

      {/* Delete Confirmation Modal */}
      {deletingTx && (
        <DeleteConfirmModal
          isOpen={Boolean(deletingTx)}
          onClose={() => setDeletingTx(null)}
          transaction={deletingTx}
        />
      )}
    </div>
  );
};

export default TransactionTable;
