import React from 'react';
import { Loader2 } from 'lucide-react';

export const LoadingSpinner = ({ label = 'Loading data...', fullScreen = false }) => {
  if (fullScreen) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 gap-4">
        <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
        <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{label}</p>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center p-6 gap-3">
      <Loader2 className="w-6 h-6 text-indigo-600 animate-spin" />
      <span className="text-sm font-medium text-slate-500 dark:text-slate-400">{label}</span>
    </div>
  );
};

export default LoadingSpinner;
