import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { storageService } from '../services/storageService';
import { useAuth } from './AuthContext';
import { useNotification } from './NotificationContext';
import { getMonthKey } from '../utils/formatters';

const TransactionContext = createContext();

export const TransactionProvider = ({ children }) => {
  const { currentUser } = useAuth();
  const { showToast } = useNotification();

  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currency, setCurrencyState] = useState('INR');
  const [userSettings, setUserSettings] = useState({});

  const userId = currentUser?.uid || 'demo_user';

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [txList, settings] = await Promise.all([
        storageService.getTransactions(userId),
        storageService.getSettings(userId),
      ]);
      setTransactions(txList || []);
      setUserSettings(settings || {});
      if (settings?.currency) {
        setCurrencyState(settings.currency);
      }
    } catch (err) {
      console.error('Failed to load transaction data:', err);
      showToast('Error loading financial data', 'error');
    } finally {
      setLoading(false);
    }
  }, [userId, showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const setCurrency = async (newCurrency) => {
    setCurrencyState(newCurrency);
    const updated = { ...userSettings, currency: newCurrency };
    setUserSettings(updated);
    await storageService.saveSettings(userId, updated);
    showToast(`Currency updated to ${newCurrency}`, 'success');
  };

  const updateSettings = async (newSettings) => {
    const updated = { ...userSettings, ...newSettings };
    setUserSettings(updated);
    if (newSettings.currency) {
      setCurrencyState(newSettings.currency);
    }
    await storageService.saveSettings(userId, updated);
    showToast('Settings saved successfully', 'success');
    return updated;
  };

  const addTransaction = async (txData) => {
    try {
      const created = await storageService.addTransaction(userId, txData);
      setTransactions((prev) => [created, ...prev]);
      showToast(
        `${txData.type === 'income' ? 'Income' : 'Expense'} added: ₹${txData.amount}`,
        'success'
      );
      return created;
    } catch (err) {
      showToast('Failed to add transaction', 'error');
      throw err;
    }
  };

  const editTransaction = async (id, updatedFields) => {
    try {
      const updated = await storageService.updateTransaction(userId, id, updatedFields);
      setTransactions((prev) =>
        prev.map((t) => (t.id === id ? { ...t, ...updatedFields } : t))
      );
      showToast('Transaction updated successfully', 'success');
      return updated;
    } catch (err) {
      showToast('Failed to update transaction', 'error');
      throw err;
    }
  };

  const deleteTransaction = async (id) => {
    try {
      await storageService.deleteTransaction(userId, id);
      setTransactions((prev) => prev.filter((t) => t.id !== id));
      showToast('Transaction deleted', 'info');
      return true;
    } catch (err) {
      showToast('Failed to delete transaction', 'error');
      throw err;
    }
  };

  const resetToDemoData = async () => {
    await storageService.resetToDemoData(userId);
    await loadData();
    showToast('Reset to demo internship dataset!', 'success');
  };

  const clearAllData = async () => {
    await storageService.clearAllData(userId);
    setTransactions([]);
    showToast('All transaction records cleared', 'info');
  };

  // COMPUTED METRICS
  const currentMonthKey = useMemo(() => getMonthKey(new Date()), []);

  const metrics = useMemo(() => {
    let totalIncome = 0;
    let totalExpenses = 0;
    let currentMonthIncome = 0;
    let currentMonthExpenses = 0;
    const categoryTotals = {};
    const monthlyAggregates = {};

    transactions.forEach((tx) => {
      const amount = Number(tx.amount) || 0;
      const isCurrentMonth = getMonthKey(tx.date) === currentMonthKey;
      const mKey = getMonthKey(tx.date);

      if (!monthlyAggregates[mKey]) {
        monthlyAggregates[mKey] = { income: 0, expense: 0, month: mKey };
      }

      if (tx.type === 'income') {
        totalIncome += amount;
        monthlyAggregates[mKey].income += amount;
        if (isCurrentMonth) {
          currentMonthIncome += amount;
        }
      } else {
        totalExpenses += amount;
        monthlyAggregates[mKey].expense += amount;
        if (isCurrentMonth) {
          currentMonthExpenses += amount;
          categoryTotals[tx.category] = (categoryTotals[tx.category] || 0) + amount;
        }
      }
    });

    const currentBalance = totalIncome - totalExpenses;
    const currentMonthBalance = currentMonthIncome - currentMonthExpenses;
    const savingsRate =
      currentMonthIncome > 0
        ? Math.max(0, Math.round(((currentMonthIncome - currentMonthExpenses) / currentMonthIncome) * 100))
        : 0;

    // Convert monthly aggregates to sorted array for charts
    const monthlyTrend = Object.keys(monthlyAggregates)
      .sort()
      .slice(-6)
      .map((k) => {
        const item = monthlyAggregates[k];
        const [y, m] = k.split('-');
        const dateObj = new Date(parseInt(y, 10), parseInt(m, 10) - 1, 1);
        const label = dateObj.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
        return {
          monthKey: k,
          label,
          income: item.income,
          expense: item.expense,
          savings: item.income - item.expense,
        };
      });

    return {
      totalIncome,
      totalExpenses,
      currentBalance,
      currentMonthIncome,
      currentMonthExpenses,
      currentMonthBalance,
      savingsRate,
      categoryTotals,
      monthlyTrend,
    };
  }, [transactions, currentMonthKey]);

  return (
    <TransactionContext.Provider
      value={{
        transactions,
        loading,
        currency,
        userSettings,
        setCurrency,
        updateSettings,
        addTransaction,
        editTransaction,
        deleteTransaction,
        resetToDemoData,
        clearAllData,
        refreshData: loadData,
        ...metrics,
      }}
    >
      {children}
    </TransactionContext.Provider>
  );
};

export const useTransactions = () => {
  const context = useContext(TransactionContext);
  if (!context) throw new Error('useTransactions must be used within TransactionProvider');
  return context;
};
