import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  signInWithPopup,
  updateProfile,
} from 'firebase/auth';
import { auth, googleProvider, isFirebaseConfigured } from '../services/firebase';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState(null);

  useEffect(() => {
    // Check if there is an active local demo session first
    const savedDemoUser = localStorage.getItem('expense_tracker_session');
    if (savedDemoUser) {
      try {
        const parsed = JSON.parse(savedDemoUser);
        setCurrentUser(parsed);
        setLoading(false);
        return;
      } catch {
        localStorage.removeItem('expense_tracker_session');
      }
    }

    if (isFirebaseConfigured && auth) {
      const unsubscribe = onAuthStateChanged(auth, (user) => {
        if (user) {
          setCurrentUser({
            uid: user.uid,
            email: user.email,
            displayName: user.displayName || user.email?.split('@')[0] || 'Intern User',
            photoURL: user.photoURL || null,
            isDemo: false,
          });
        } else {
          // If no Firebase user and no saved demo session, currentUser is null
          const session = localStorage.getItem('expense_tracker_session');
          if (!session) {
            setCurrentUser(null);
          }
        }
        setLoading(false);
      });
      return unsubscribe;
    } else {
      // By default if no Firebase is configured, auto-login as Demo Intern User so the user can immediately preview!
      const defaultDemoUser = {
        uid: 'demo_user',
        email: 'intern@codectechnologies.com',
        displayName: 'Anand Sharma (Intern)',
        photoURL: null,
        isDemo: true,
      };
      setCurrentUser(defaultDemoUser);
      localStorage.setItem('expense_tracker_session', JSON.stringify(defaultDemoUser));
      setLoading(false);
    }
  }, []);

  const loginWithDemo = () => {
    const demoUser = {
      uid: 'demo_user',
      email: 'intern@codectechnologies.com',
      displayName: 'Anand Sharma (Intern)',
      photoURL: null,
      isDemo: true,
    };
    setCurrentUser(demoUser);
    localStorage.setItem('expense_tracker_session', JSON.stringify(demoUser));
    return Promise.resolve(demoUser);
  };

  const login = async (email, password) => {
    setAuthError(null);
    if (!isFirebaseConfigured || !auth) {
      // Offline/Local mock authentication
      const mockUser = {
        uid: `user_${email.replace(/[^a-zA-Z0-9]/g, '_')}`,
        email,
        displayName: email.split('@')[0],
        photoURL: null,
        isDemo: true,
      };
      setCurrentUser(mockUser);
      localStorage.setItem('expense_tracker_session', JSON.stringify(mockUser));
      return mockUser;
    }

    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      localStorage.removeItem('expense_tracker_session');
      return result.user;
    } catch (err) {
      setAuthError(err.message);
      throw err;
    }
  };

  const register = async (email, password, displayName) => {
    setAuthError(null);
    if (!isFirebaseConfigured || !auth) {
      const mockUser = {
        uid: `user_${email.replace(/[^a-zA-Z0-9]/g, '_')}`,
        email,
        displayName: displayName || email.split('@')[0],
        photoURL: null,
        isDemo: true,
      };
      setCurrentUser(mockUser);
      localStorage.setItem('expense_tracker_session', JSON.stringify(mockUser));
      return mockUser;
    }

    try {
      const result = await createUserWithEmailAndPassword(auth, email, password);
      if (displayName && result.user) {
        await updateProfile(result.user, { displayName });
      }
      localStorage.removeItem('expense_tracker_session');
      return result.user;
    } catch (err) {
      setAuthError(err.message);
      throw err;
    }
  };

  const loginWithGoogle = async () => {
    setAuthError(null);
    if (!isFirebaseConfigured || !auth || !googleProvider) {
      return loginWithDemo();
    }
    try {
      const result = await signInWithPopup(auth, googleProvider);
      localStorage.removeItem('expense_tracker_session');
      return result.user;
    } catch (err) {
      setAuthError(err.message);
      throw err;
    }
  };

  const logout = async () => {
    localStorage.removeItem('expense_tracker_session');
    if (isFirebaseConfigured && auth) {
      try {
        await signOut(auth);
      } catch (err) {
        console.error('Sign out error:', err);
      }
    }
    setCurrentUser(null);
  };

  const updateUserProfile = async ({ displayName }) => {
    if (currentUser?.isDemo) {
      const updated = { ...currentUser, displayName };
      setCurrentUser(updated);
      localStorage.setItem('expense_tracker_session', JSON.stringify(updated));
      return true;
    }

    if (auth?.currentUser) {
      await updateProfile(auth.currentUser, { displayName });
      setCurrentUser((prev) => ({ ...prev, displayName }));
      return true;
    }
    return false;
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        loading,
        authError,
        isFirebaseConfigured,
        login,
        register,
        loginWithGoogle,
        loginWithDemo,
        logout,
        updateUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
