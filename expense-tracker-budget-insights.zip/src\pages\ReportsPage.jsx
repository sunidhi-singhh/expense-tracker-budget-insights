import React, { useState } from 'react';
import {
  Download,
  Printer,
  TrendingUp,
  TrendingDown,
  PiggyBank,
  Percent,
  Calendar,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import StatCard from '../components/common/StatCard';
import CategoryBreakdownTable from '../components/reports/CategoryBreakdownTable';
import PrintableReport from '../components/reports/PrintableReport';
import { useTransactions } from '../context/TransactionContext';
import { useBudget } from '../context/BudgetContext';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { exportTransactionsToCsv } from '../utils/exportCsv';
import { formatCurrency } from '../utils/formatters';

export const ReportsPage = () => {
  const {
    transactions,
    currentMonthIncome,
    currentMonthExpenses,
    currentMonthBalance,
    savingsRate,
    monthlyTrend,
    categoryTotals,
    currency,
  } = useTransactions();

  const { overallBudget, overallPercentage } = useBudget();
  const { currentUser } = useAuth();
  const { isDark } = useTheme();

  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  const handleExportCsv = () => {
    exportTransactionsToCsv(
      transactions,
      `financial_report_${new Date().toISOString().split('T')[0]}.csv`
    );
  };

  const CustomAreaTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
          <p className="font-bold text-slate-800 dark:text-slate-200">{label}</p>
          <p className="text-emerald-600 font-semibold">
            Income: {formatCurrency(payload[0]?.value || 0, currency)}
          </p>
          <p className="text-rose-600 font-semibold">
            Expense: {formatCurrency(payload[1]?.value || 0, currency)}
          </p>
          <p className="text-indigo-600 font-bold pt-1 border-t border-slate-100 dark:border-slate-800">
            Net Savings: {formatCurrency((payload[0]?.value || 0) - (payload[1]?.value || 0), currency)}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header with Export & Print buttons */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Reports & Analytics
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Examine cash flow trends, spending breakdown, and export audit statements.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60 rounded-xl transition shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Export to CSV</span>
          </button>
          <button
            onClick={() => setIsPrintModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-md shadow-indigo-600/20 active:scale-95"
          >
            <Printer className="w-4 h-4" />
            <span>Print Monthly Summary</span>
          </button>
        </div>
      </div>

      {/* 4 Summary Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <StatCard
          title="Total Inflow"
          amount={formatCurrency(currentMonthIncome, currency)}
          subtitle="Monthly cash receipts"
          icon={TrendingUp}
          variant="income"
        />
        <StatCard
          title="Total Outflow"
          amount={formatCurrency(currentMonthExpenses, currency)}
          subtitle="Monthly expenditures"
          icon={TrendingDown}
          variant="expense"
        />
        <StatCard
          title="Net Monthly Savings"
          amount={formatCurrency(currentMonthBalance, currency)}
          subtitle="Saved after expenses"
          icon={PiggyBank}
          variant="balance"
        />
        <StatCard
          title="Savings Rate"
          amount={`${savingsRate}%`}
          subtitle="Of monthly income saved"
          icon={Percent}
          variant={savingsRate >= 20 ? 'income' : 'warning'}
        />
      </div>

      {/* Monthly Trend Area Chart */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Financial Trend & Cash Flow Area
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Cumulative income vs expenses trajectory over time
            </p>
          </div>
        </div>

        <div className="h-64 sm:h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={monthlyTrend} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
              <defs>
                <linearGradient id="incomeGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="expenseGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
                stroke={isDark ? '#334155' : '#f1f5f9'}
              />
              <XAxis
                dataKey="label"
                stroke={isDark ? '#94a3b8' : '#64748b'}
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke={isDark ? '#94a3b8' : '#64748b'}
                fontSize={11}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `${v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v}`}
              />
              <Tooltip content={<CustomAreaTooltip />} />
              <Area
                type="monotone"
                dataKey="income"
                stroke="#10b981"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#incomeGradient)"
              />
              <Area
                type="monotone"
                dataKey="expense"
                stroke="#f43f5e"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#expenseGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Category Breakdown Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Category Breakdown Table
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Spending volume and percentage contribution per category
          </p>
        </div>
        <CategoryBreakdownTable
          categoryTotals={categoryTotals}
          totalExpenses={currentMonthExpenses}
          currency={currency}
          transactions={transactions}
        />
      </div>

      {/* Printable Report Modal */}
      <PrintableReport
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        currentUser={currentUser}
        currentMonthIncome={currentMonthIncome}
        currentMonthExpenses={currentMonthExpenses}
        currentMonthBalance={currentMonthBalance}
        savingsRate={savingsRate}
        overallBudget={overallBudget}
        overallPercentage={overallPercentage}
        categoryTotals={categoryTotals}
        currency={currency}
        transactions={transactions}
      />
    </div>
  );
};

export default ReportsPage;
