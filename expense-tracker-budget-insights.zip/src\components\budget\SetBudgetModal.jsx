import React, { useState, useEffect } from 'react';
import Modal from '../common/Modal';
import { useBudget } from '../../context/BudgetContext';
import { useTransactions } from '../../context/TransactionContext';
import { CATEGORIES } from '../../utils/constants';

export const SetBudgetModal = ({ isOpen, onClose }) => {
  const { budgets, updateAllBudgets } = useBudget();
  const { currency } = useTransactions();

  const [overall, setOverall] = useState(45000);
  const [categories, setCategories] = useState({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (budgets) {
      setOverall(budgets.overall || 45000);
      setCategories(budgets.categories || {});
    }
  }, [budgets, isOpen]);

  const handleCategoryChange = (catId, value) => {
    setCategories((prev) => ({
      ...prev,
      [catId]: Math.max(0, parseFloat(value) || 0),
    }));
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateAllBudgets({
        overall: Math.max(0, parseFloat(overall) || 0),
        categories,
      });
      onClose();
    } catch (err) {
      console.error('Save budget error:', err);
    } finally {
      setSaving(false);
    }
  };

  // Only expense categories have budgets
  const expenseCategories = Object.values(CATEGORIES).filter((c) => c.type === 'expense');

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Set Monthly Budget Limits"
      subtitle="Define your monthly spending targets and category limits"
      maxWidth="max-w-xl"
    >
      <form onSubmit={handleSave} className="space-y-4">
        {/* Overall Budget */}
        <div className="p-3.5 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-200 dark:border-indigo-900/60">
          <label className="block text-xs font-bold text-indigo-950 dark:text-indigo-200 uppercase tracking-wider mb-1">
            Total Monthly Budget ({currency})
          </label>
          <input
            type="number"
            min="0"
            step="100"
            value={overall}
            onChange={(e) => setOverall(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-bold text-base focus:outline-none focus:ring-2 focus:ring-indigo-500"
            required
          />
          <p className="text-xs text-indigo-700 dark:text-indigo-300 mt-1">
            We will alert you when your expenditures hit 80% and 100% of this overall limit.
          </p>
        </div>

        {/* Category Spending Limits */}
        <div>
          <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
            Category-wise Limits ({currency})
          </h4>
          <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
            {expenseCategories.map((cat) => (
              <div
                key={cat.id}
                className="flex items-center justify-between gap-3 p-2 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800"
              >
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 min-w-0 truncate">
                  {cat.name}
                </span>
                <input
                  type="number"
                  min="0"
                  step="50"
                  placeholder="No limit"
                  value={categories[cat.id] ?? ''}
                  onChange={(e) => handleCategoryChange(cat.id, e.target.value)}
                  className="w-32 px-3 py-1.5 text-xs text-right rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save Budgets'}
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default SetBudgetModal;
