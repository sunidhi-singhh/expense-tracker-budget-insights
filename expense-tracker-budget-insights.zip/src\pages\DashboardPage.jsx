import React, { useState } from 'react';
import { Plus, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';
import OverviewSummary from '../components/dashboard/OverviewSummary';
import IncomeExpenseChart from '../components/dashboard/IncomeExpenseChart';
import CategoryDoughnutChart from '../components/dashboard/CategoryDoughnutChart';
import RecentTransactionsList from '../components/dashboard/RecentTransactionsList';
import BudgetAlertBanner from '../components/budget/BudgetAlertBanner';
import TransactionFormModal from '../components/transactions/TransactionFormModal';
import { useAuth } from '../context/AuthContext';
import { useTransactions } from '../context/TransactionContext';

export const DashboardPage = () => {
  const { currentUser, isFirebaseConfigured } = useAuth();
  const { loading } = useTransactions();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner / Welcome Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Financial Overview
            </h1>
            {currentUser?.isDemo ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300">
                <Sparkles className="w-3 h-3" /> Internship Demo
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300">
                <ShieldCheck className="w-3 h-3" /> Live Firestore
              </span>
            )}
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Real-time tracking, category budgets, and financial health insights.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-md shadow-indigo-600/20 active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Transaction</span>
        </button>
      </div>

      {/* Budget Warning Banner (if budget thresholds are exceeded or >=80%) */}
      <BudgetAlertBanner />

      {/* 4 Key Summary Stat Cards */}
      <OverviewSummary />

      {/* Charts Section: Income vs Expense & Category Doughnut */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <IncomeExpenseChart />
        <CategoryDoughnutChart />
      </div>

      {/* Recent Transactions List */}
      <RecentTransactionsList />

      {/* Add Transaction Modal */}
      <TransactionFormModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />
    </div>
  );
};

export default DashboardPage;
