import React, { useState } from 'react';
import {
  SlidersHorizontal,
  AlertTriangle,
  AlertOctagon,
  CheckCircle2,
  PieChart,
  Wallet,
} from 'lucide-react';
import CategoryBudgetCard from '../components/budget/CategoryBudgetCard';
import SetBudgetModal from '../components/budget/SetBudgetModal';
import { useBudget } from '../context/BudgetContext';
import { useTransactions } from '../context/TransactionContext';
import { formatCurrency } from '../../src/utils/formatters';

export const BudgetPage = () => {
  const {
    overallBudget,
    overallSpent,
    overallRemaining,
    overallPercentage,
    overallStatus,
    categoryStatusList,
    alerts,
  } = useBudget();

  const { currency } = useTransactions();
  const [isSetBudgetOpen, setIsSetBudgetOpen] = useState(false);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Budget Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Set spending targets, track category quotas, and receive smart budget alerts.
          </p>
        </div>

        <button
          onClick={() => setIsSetBudgetOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-md shadow-indigo-600/20 active:scale-95"
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span>Adjust Budget Limits</span>
        </button>
      </div>

      {/* Main Overall Monthly Budget Hero Card */}
      <div className="bg-gradient-to-br from-indigo-900 via-indigo-800 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="relative z-10 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs uppercase font-extrabold tracking-widest text-indigo-300">
                Monthly Target Overview
              </span>
              <h2 className="text-3xl sm:text-4xl font-black mt-1 tracking-tight">
                {formatCurrency(overallBudget, currency)}
              </h2>
              <p className="text-xs sm:text-sm text-indigo-200 mt-1">
                Total expenditure limit for this calendar month
              </p>
            </div>

            {/* Overall Status Badge */}
            <div className="self-start sm:self-center">
              {overallStatus === 'exceeded' ? (
                <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-500/20 border border-rose-400/40 text-rose-300 text-xs font-bold backdrop-blur-md">
                  <AlertOctagon className="w-4 h-4 text-rose-400" />
                  <span>Budget Exceeded ({overallPercentage}%)</span>
                </div>
              ) : overallStatus === 'warning' ? (
                <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-bold backdrop-blur-md">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>Warning: 80% Reached ({overallPercentage}%)</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-bold backdrop-blur-md">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Within Budget ({overallPercentage}%)</span>
                </div>
              )}
            </div>
          </div>

          {/* Hero Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs sm:text-sm font-semibold text-indigo-200">
              <span>Spent: {formatCurrency(overallSpent, currency)}</span>
              <span>
                Remaining:{' '}
                {overallRemaining < 0
                  ? `-${formatCurrency(Math.abs(overallRemaining), currency)}`
                  : formatCurrency(overallRemaining, currency)}
              </span>
            </div>
            <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden backdrop-blur-sm p-0.5 border border-white/10">
              <div
                className={`h-full rounded-full transition-all duration-700 ${
                  overallStatus === 'exceeded'
                    ? 'bg-gradient-to-r from-rose-500 to-red-400'
                    : overallStatus === 'warning'
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-400'
                    : 'bg-gradient-to-r from-emerald-400 to-teal-300'
                }`}
                style={{ width: `${Math.min(100, overallPercentage)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Ambient background blur shapes */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-64 h-64 bg-purple-500/20 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Active Threshold Alerts List */}
      {alerts.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            Active Budget Alerts ({alerts.length})
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {alerts.map((alert, index) => (
              <div
                key={index}
                className={`p-3.5 rounded-xl border flex items-start gap-3 ${
                  alert.type === 'exceeded'
                    ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900/60 text-rose-900 dark:text-rose-200'
                    : 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900/60 text-amber-900 dark:text-amber-200'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${
                    alert.type === 'exceeded'
                      ? 'bg-rose-100 text-rose-600 dark:bg-rose-900 dark:text-rose-300'
                      : 'bg-amber-100 text-amber-600 dark:bg-amber-900 dark:text-amber-300'
                  }`}
                >
                  {alert.type === 'exceeded' ? (
                    <AlertOctagon className="w-4 h-4" />
                  ) : (
                    <AlertTriangle className="w-4 h-4" />
                  )}
                </div>
                <div>
                  <h4 className="text-xs font-bold">{alert.title}</h4>
                  <p className="text-xs opacity-90 mt-0.5">{alert.message}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Category-Wise Budgets Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Category Spending Limits
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Live consumption vs. limit per expense category
            </p>
          </div>
        </div>

        {categoryStatusList.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 text-center text-slate-500 text-sm">
            No category spending limits set yet. Click "Adjust Budget Limits" to add category targets.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {categoryStatusList.map((catStatus) => (
              <CategoryBudgetCard
                key={catStatus.categoryId}
                categoryStatus={catStatus}
                currency={currency}
                onEdit={() => setIsSetBudgetOpen(true)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Set Budget Modal */}
      <SetBudgetModal
        isOpen={isSetBudgetOpen}
        onClose={() => setIsSetBudgetOpen(false)}
      />
    </div>
  );
};

export default BudgetPage;
