import React, { useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import Modal from '../common/Modal';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { useTransactions } from '../../context/TransactionContext';

export const DeleteConfirmModal = ({
  isOpen,
  onClose,
  transaction,
}) => {
  const { deleteTransaction, currency } = useTransactions();
  const [deleting, setDeleting] = useState(false);

  if (!transaction) return null;

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteTransaction(transaction.id);
      onClose();
    } catch (err) {
      console.error('Delete error:', err);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Delete Transaction"
      subtitle="This action cannot be undone."
      maxWidth="max-w-md"
    >
      <div className="space-y-4">
        <div className="flex items-center gap-3 p-3.5 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-200 dark:border-rose-900/60">
          <div className="w-10 h-10 rounded-lg bg-rose-100 dark:bg-rose-900/80 flex items-center justify-center text-rose-600 flex-shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-rose-900 dark:text-rose-200">
              Confirm Record Deletion
            </h4>
            <p className="text-xs text-rose-700 dark:text-rose-400 mt-0.5">
              Are you sure you want to remove this financial record?
            </p>
          </div>
        </div>

        {/* Transaction Summary Card */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-1 text-sm border border-slate-200 dark:border-slate-700/80">
          <div className="flex justify-between">
            <span className="text-slate-500 dark:text-slate-400">Title:</span>
            <span className="font-semibold text-slate-800 dark:text-slate-200">{transaction.title}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500 dark:text-slate-400">Amount:</span>
            <span className={`font-bold ${transaction.type === 'income' ? 'text-emerald-600' : 'text-rose-600'}`}>
              {transaction.type === 'income' ? '+' : '-'} {formatCurrency(transaction.amount, currency)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500 dark:text-slate-400">Date:</span>
            <span className="text-slate-700 dark:text-slate-300">{formatDate(transaction.date)}</span>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleDelete}
            disabled={deleting}
            className="px-5 py-2 text-sm font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition shadow-sm disabled:opacity-50"
          >
            {deleting ? 'Deleting...' : 'Yes, Delete'}
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default DeleteConfirmModal;
