export const TRANSACTION_TYPES = {
  INCOME: 'income',
  EXPENSE: 'expense',
};

export const CATEGORIES = {
  // Expense categories
  food: { id: 'food', name: 'Food & Dining', type: 'expense', icon: 'Utensils', color: '#f97316', bg: 'bg-orange-100 text-orange-700 dark:bg-orange-950/60 dark:text-orange-300' },
  housing: { id: 'housing', name: 'Housing & Rent', type: 'expense', icon: 'Home', color: '#6366f1', bg: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300' },
  utilities: { id: 'utilities', name: 'Utilities & Bills', type: 'expense', icon: 'Zap', color: '#eab308', bg: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-950/60 dark:text-yellow-300' },
  transport: { id: 'transport', name: 'Transportation', type: 'expense', icon: 'Car', color: '#06b6d4', bg: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/60 dark:text-cyan-300' },
  entertainment: { id: 'entertainment', name: 'Entertainment', type: 'expense', icon: 'Film', color: '#ec4899', bg: 'bg-pink-100 text-pink-700 dark:bg-pink-950/60 dark:text-pink-300' },
  shopping: { id: 'shopping', name: 'Shopping', type: 'expense', icon: 'ShoppingBag', color: '#a855f7', bg: 'bg-purple-100 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300' },
  healthcare: { id: 'healthcare', name: 'Healthcare & Fitness', type: 'expense', icon: 'HeartPulse', color: '#ef4444', bg: 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300' },
  education: { id: 'education', name: 'Education & Courses', type: 'expense', icon: 'GraduationCap', color: '#14b8a6', bg: 'bg-teal-100 text-teal-700 dark:bg-teal-950/60 dark:text-teal-300' },
  travel: { id: 'travel', name: 'Travel & Vacations', type: 'expense', icon: 'Plane', color: '#3b82f6', bg: 'bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300' },
  other_expense: { id: 'other_expense', name: 'Other Expense', type: 'expense', icon: 'MoreHorizontal', color: '#64748b', bg: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300' },

  // Income categories
  salary: { id: 'salary', name: 'Salary / Stipend', type: 'income', icon: 'Briefcase', color: '#10b981', bg: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300' },
  freelance: { id: 'freelance', name: 'Freelance & Projects', type: 'income', icon: 'Laptop', color: '#0ea5e9', bg: 'bg-sky-100 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300' },
  investments: { id: 'investments', name: 'Investments & Returns', type: 'income', icon: 'TrendingUp', color: '#8b5cf6', bg: 'bg-violet-100 text-violet-700 dark:bg-violet-950/60 dark:text-violet-300' },
  bonus: { id: 'bonus', name: 'Bonus & Incentives', type: 'income', icon: 'Award', color: '#f59e0b', bg: 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300' },
  gifts: { id: 'gifts', name: 'Gifts & Allowance', type: 'income', icon: 'Gift', color: '#f43f5e', bg: 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300' },
  other_income: { id: 'other_income', name: 'Other Income', type: 'income', icon: 'DollarSign', color: '#059669', bg: 'bg-green-100 text-green-700 dark:bg-green-950/60 dark:text-green-300' },
};

export const PAYMENT_METHODS = [
  'UPI / Online',
  'Credit Card',
  'Debit Card',
  'Net Banking',
  'Cash',
  'Cheque',
  'Other',
];

export const CURRENCIES = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee (INR)' },
  { code: 'USD', symbol: '$', name: 'US Dollar (USD)' },
  { code: 'EUR', symbol: '€', name: 'Euro (EUR)' },
  { code: 'GBP', symbol: '£', name: 'British Pound (GBP)' },
  { code: 'CAD', symbol: 'CA$', name: 'Canadian Dollar (CAD)' },
  { code: 'AUD', symbol: 'AU$', name: 'Australian Dollar (AUD)' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen (JPY)' },
  { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar (SGD)' },
];

export const BUDGET_THRESHOLDS = {
  WARNING: 80, // percentage
  EXCEEDED: 100, // percentage
};
