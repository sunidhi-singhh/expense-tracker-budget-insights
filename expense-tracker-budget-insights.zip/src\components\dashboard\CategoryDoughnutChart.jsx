import React, { useMemo } from 'react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
} from 'recharts';
import { useTransactions } from '../../context/TransactionContext';
import { getCategoryMeta, formatCurrency } from '../../utils/formatters';

const DEFAULT_COLORS = [
  '#f97316',
  '#6366f1',
  '#eab308',
  '#06b6d4',
  '#ec4899',
  '#a855f7',
  '#ef4444',
  '#14b8a6',
  '#3b82f6',
  '#64748b',
];

export const CategoryDoughnutChart = () => {
  const { categoryTotals, currentMonthExpenses, currency } = useTransactions();

  const chartData = useMemo(() => {
    return Object.entries(categoryTotals || {})
      .map(([catId, amount], idx) => {
        const meta = getCategoryMeta(catId);
        return {
          id: catId,
          name: meta.name,
          value: amount,
          color: meta.color || DEFAULT_COLORS[idx % DEFAULT_COLORS.length],
          percentage:
            currentMonthExpenses > 0
              ? Math.round((amount / currentMonthExpenses) * 100)
              : 0,
        };
      })
      .filter((item) => item.value > 0)
      .sort((a, b) => b.value - a.value);
  }, [categoryTotals, currentMonthExpenses]);

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-slate-900 p-2.5 rounded-xl shadow-lg border border-slate-200 dark:border-slate-800 text-xs">
          <p className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
            <span
              className="w-2.5 h-2.5 rounded-full inline-block"
              style={{ backgroundColor: data.color }}
            />
            {data.name}
          </p>
          <p className="text-slate-600 dark:text-slate-300 font-semibold mt-1">
            {formatCurrency(data.value, currency)} ({data.percentage}%)
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
      <div className="mb-2">
        <h3 className="text-base font-bold text-slate-900 dark:text-white">
          Expenses by Category
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Spending distribution for this month
        </p>
      </div>

      {chartData.length === 0 ? (
        <div className="h-64 flex flex-col items-center justify-center text-slate-400 text-sm">
          <span>No expense records for this month</span>
        </div>
      ) : (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="h-56 w-56 relative flex-shrink-0">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Tooltip content={<CustomTooltip />} />
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {chartData.map((entry) => (
                    <Cell key={entry.id} fill={entry.color} stroke="none" />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
              <span className="text-[11px] font-medium text-slate-400">Total Spent</span>
              <span className="text-sm font-bold text-slate-900 dark:text-white">
                {formatCurrency(currentMonthExpenses, currency)}
              </span>
            </div>
          </div>

          {/* Category Top Breakdown List */}
          <div className="w-full sm:flex-1 max-h-56 overflow-y-auto space-y-2 pr-1">
            {chartData.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800/80"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="font-medium text-slate-700 dark:text-slate-300 truncate">
                    {item.name}
                  </span>
                </div>
                <div className="flex items-center gap-3 font-semibold text-slate-900 dark:text-slate-100 flex-shrink-0">
                  <span>{formatCurrency(item.value, currency)}</span>
                  <span className="text-slate-400 text-[11px] w-8 text-right">
                    {item.percentage}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CategoryDoughnutChart;
