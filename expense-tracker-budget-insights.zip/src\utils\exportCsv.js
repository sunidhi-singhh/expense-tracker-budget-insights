import { getCategoryMeta } from './formatters';

export const exportTransactionsToCsv = (transactions, filename = 'expense-tracker-transactions.csv') => {
  if (!transactions || transactions.length === 0) {
    alert('No transactions available to export.');
    return;
  }

  const headers = ['Date', 'Title', 'Type', 'Category', 'Amount', 'Payment Method', 'Notes'];

  const rows = transactions.map((t) => {
    const category = getCategoryMeta(t.category).name;
    const cleanNotes = (t.notes || '').replace(/"/g, '""');
    const cleanTitle = (t.title || '').replace(/"/g, '""');

    return [
      `"${t.date || ''}"`,
      `"${cleanTitle}"`,
      `"${t.type?.toUpperCase() || 'EXPENSE'}"`,
      `"${category}"`,
      `"${t.amount || 0}"`,
      `"${t.paymentMethod || 'N/A'}"`,
      `"${cleanNotes}"`,
    ].join(',');
  });

  const csvContent = [headers.join(','), ...rows].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
